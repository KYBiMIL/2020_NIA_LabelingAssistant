//
//  SlideReferImagesVC_Class.swift
//  LabelingAssistant4ML
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class ReferImageInfo {
    var group:String?
    var imageUrl:String?
}

class ReferImageList {
    var images:[ReferImageInfo] = [ReferImageInfo]()
    var count:Int {
        get {
            return images.count
        }
    }
    
    var groupList:[String] {
        get {
            var grouplist:[String] = [String]()
            var exist = false
            for image in images {
                exist = false
                for name in grouplist {
                    if (name == image.group) {
                        exist = true
                    }
                }
                if (!exist) {
                    grouplist.append(image.group!)
                }
            }
            return grouplist
        }
    }
    
    func imagesByGroup(group:String) -> [ReferImageInfo] {
        var referImageList: [ReferImageInfo] = []
        for image in images {
            if (image.group == group) {
                referImageList.append(image)
            }
        }
        return referImageList
    }

    func append(group:String, imageUrl:String) {
        let referImageInfo:ReferImageInfo = ReferImageInfo()
        referImageInfo.group = group
        referImageInfo.imageUrl = imageUrl
        images.append(referImageInfo)
    }

    func append(referImageInfo:ReferImageInfo) {
        images.append(referImageInfo)
    }
    
    func removeAll() {
        images.removeAll()
    }
    
}

