//
//  Func_Color.swift
//  LabelingAssistant4ML
//
//  Created by Myeong-Joon Son on 14/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

// ---------------------------------------------------------------------
// user defualt key 정의
// ---------------------------------------------------------------------
let TintColorKey = "TintColor"

// ---------------------------------------------------------------------
// tint color enum
// ---------------------------------------------------------------------
enum EnumTintColor:Int, CaseIterable{
    case Blue = 0, Orange, Black, Purple
    var color:UIColor { get {
        switch self {
        case .Blue:
            return UIColor.lightBlue
        //return UIColor(displayP3Red: 0.0, green: 122.0/255.0, blue: 1.0, alpha: 1.0)
        case .Orange:
            return UIColor.orange
        case .Black:
            return UIColor.black
        case .Purple:
            return UIColor.purple
        }
        }}
    var title:String { get {
        switch self {
        case .Blue:
            return "블루"
        case .Orange:
            return "오렌지"
        case .Black:
            return "블랙"
        case .Purple:
            return "퍼플"
        }
        }}
}

// ---------------------------------------------------------------------
// tint color 세팅
// ---------------------------------------------------------------------
func SetTintColor(color:UIColor) {
    guard let window = UIApplication.shared.keyWindow else {
        return
    }
    window.tintColor = color
}

// ---------------------------------------------------------------------
// 현재 tint color 가져오기
// ---------------------------------------------------------------------
func GetTintColor() -> UIColor {
    guard let window = UIApplication.shared.keyWindow else {
        return EnumTintColor(rawValue: 0)!.color
    }
    if window.tintColor == nil {
        return EnumTintColor(rawValue: 0)!.color
    }
    else {
        return window.tintColor
    }
}

func ColorWithHexString(hexString: String, alpha:CGFloat? = 1.0) -> UIColor {
    let hexint = Int(IntFromHexString(hexStr: hexString))
    let red = CGFloat((hexint & 0xff0000) >> 16) / 255.0
    let green = CGFloat((hexint & 0xff00) >> 8) / 255.0
    let blue = CGFloat((hexint & 0xff) >> 0) / 255.0
    let alpha = alpha!
    
    let color = UIColor(red: red, green: green, blue: blue, alpha: alpha)
    return color
}

func IntFromHexString(hexStr: String) -> UInt32 {
    var hexInt: UInt32 = 0
    let scanner: Scanner = Scanner(string: hexStr)
    scanner.charactersToBeSkipped = CharacterSet(charactersIn: "#")
    scanner.scanHexInt32(&hexInt)
    return hexInt
}


// ---------------------------------------------------------------------
// drawing color enum
// ---------------------------------------------------------------------
enum EnumDrawingColor:Int, CaseIterable{
    case Red = 0, Orange, Yellow, White, Blue
    var color:UIColor { get {
        switch self {
        case .Red:
            return UIColor.red
        case .Blue:
            return UIColor.blue
        case .Yellow:
            return UIColor.yellow
        case .White:
            return UIColor.white
        case .Orange:
            return UIColor.orange
        }
        }}
    var displayColor:UIColor { get {
        switch self {
        case .Red:
            return UIColor.red
        case .Blue:
            return UIColor.blue
        case .Yellow:
            return UIColor.darkYellow
        case .White:
            return UIColor.darkWhite
        case .Orange:
            return UIColor.orange
        }
        }}
    var title:String { get {
        switch self {
        case .Red:
            return "빨강"
        case .Blue:
            return "파랑"
        case .Yellow:
            return "노랑"
        case .White:
            return "하양"
        case .Orange:
            return "주황"
        }
        }}
}

extension UIColor {
    
    // Setup custom colours we can use throughout the app using hex values
    static let lightBlue = UIColor(displayP3Red: 0.0, green: 122.0/255.0, blue: 1.0, alpha: 1.0)
    static let youtubeRed = UIColor(hex: 0xf80000)
    static let transparentBlack = UIColor(hex: 0x000000, a: 0.5)
    static let darkYellow = UIColor(hex: 0xcccc00)
    static let darkWhite = UIColor(hex: 0xc0c0c0)

    // Create a UIColor from RGB
    convenience init(red: Int, green: Int, blue: Int, a: CGFloat = 1.0) {
        self.init(
            red: CGFloat(red) / 255.0,
            green: CGFloat(green) / 255.0,
            blue: CGFloat(blue) / 255.0,
            alpha: a
        )
    }
    
    // Create a UIColor from a hex value (E.g 0x000000)
    convenience init(hex: Int, a: CGFloat = 1.0) {
        self.init(
            red: (hex >> 16) & 0xFF,
            green: (hex >> 8) & 0xFF,
            blue: hex & 0xFF,
            a: a
        )
    }
}
