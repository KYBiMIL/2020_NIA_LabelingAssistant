//
//  Func_Orientation.swift
//  LabelingAssistant4ML
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

let OrientationKey = "Orientation"
var OrientationValue = UIInterfaceOrientationMask.portrait

enum EnumOrientation:Int, CaseIterable {
    case Portrait = 0, Landscape
    var orientation:UIInterfaceOrientationMask { get {
        switch self {
        case .Portrait:
            return .portrait
        case .Landscape:
            return .landscape
        }
        }}
    var title:String { get {
        switch self {
        case .Portrait:
            return "세로모드"
        case .Landscape:
            return "가로모드"
        }
        }}
}

func SetOrientation() {

    switch OrientationValue {
    case .portrait:
        if UIDevice.current.orientation == UIDeviceOrientation.portrait {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown])
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.portraitUpsideDown {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown])
        }
        else if UIDevice.current.orientation.isLandscape  {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown], andRotateTo: .portrait)
        }
        else {
            AppDelegate.AppUtility.lockOrientation([.portrait, .portraitUpsideDown], andRotateTo: .portrait)
            p("SetOrientation() : portrait, else")
        }

    case .landscape:
        if UIDevice.current.orientation == UIDeviceOrientation.landscapeLeft {
            AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight])
        }
        else if UIDevice.current.orientation == UIDeviceOrientation.landscapeRight {
            AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight])
        }
        else if UIDevice.current.orientation.isPortrait  {
            AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight], andRotateTo: .landscapeLeft)
        }
        else {
            AppDelegate.AppUtility.lockOrientation([.landscapeLeft, .landscapeRight], andRotateTo: .landscapeLeft)
        }

    default :
        AppDelegate.AppUtility.lockOrientation([.portrait], andRotateTo: .portraitUpsideDown)
        p("SetOrientation() : default")
    }
}
