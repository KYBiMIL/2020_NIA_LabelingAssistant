//
//  Class_FreeCurve.swift
//  testSaveImage
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

struct Line {
    var isClip:Bool
    let type:LineType
    let width:CGFloat
    let color:UIColor
    var fillcolor:UIColor
    var alpha:CGFloat
    var points: [CGPoint]
}

enum LineType : CustomStringConvertible  {
    case FreeCurve
    case ClosedCurve
    case Ellipse
    case Polygon
    case Eraser
    var description: String {
        switch self {
        case .FreeCurve: return "자유형"
        case .ClosedCurve: return "닫힌자유형"
        case .Ellipse: return "타원형"
        case .Polygon: return "다각형"
        case .Eraser: return "지우개"
        }
    }
    static var allValues = [LineType.FreeCurve, .ClosedCurve, .Ellipse, .Polygon]
}

class Canvas:UIView {
    
    fileprivate var _isDrawing: Bool
    var isDrawing: Bool {
        get {
            return _isDrawing
        }
        set(newVal) {
            _isDrawing = newVal
            if (newVal) {
                //undolines.removeAll()
            }
        }
    }
    
    var lineWidth:CGFloat = 2.0
    var isClosedCurve:Bool = false
    
    var lines = [Line]()
    var clippingLines: [Line] {
        get {
            var clines = [Line]()
            lines.forEach { (line) in
                if (line.isClip) {
                    clines.append(line)
                }
            }
            return clines
        }
    }
    var markedLines: [Line] {
        get {
            var clines = [Line]()
            lines.forEach { (line) in
                if (!line.isClip) {
                    clines.append(line)
                }
            }
            return clines
        }
    }

    var undoCount: Int {
        get {
            return undolines.count
        }
    }
    
    fileprivate var undolines = [Line]()

    fileprivate let shapeLayer = CAShapeLayer()
    fileprivate let path = UIBezierPath()

    override init(frame: CGRect) {
        _isDrawing = false
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
//        shapeLayer.frame = self.frame
//        shapeLayer.fillColor = UIColor.clear.cgColor
//        self.layer.addSublayer(shapeLayer)
    }
    
    required init?(coder aDecoder: NSCoder) {
        _isDrawing = false
        super.init(coder: aDecoder)
    }
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        drawLine()
    }
    
    fileprivate func drawLine() {
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }

        // clipping path, 먼저 clipping path를 그린 후에 실제 마크를 그려야 함
        if clippingLines.count > 0 {
            let clipPath = UIBezierPath.init(rect: .infinite)
            clipPath.usesEvenOddFillRule = true

            let clippingPath = UIBezierPath()
            clippingLines.forEach { (line) in
                addClippingPath(path: clippingPath, line: line)
            }
            setClippingPathProperty(path: clippingPath)
            clipPath.append(clippingPath)
            clipPath.addClip()
        }
        
//        let rect = CGRect(x: 200, y: 200, width: 200, height: 200)
//        let radius          = rect.height * 0.25
//        let centerX         = rect.width  * 0.5
//        let centerY         = rect.height * 0.5
//        let arcCenterOffset = radius - radius * 0.5 * sqrt(3)
//        let degree:(_: CGFloat) -> CGFloat = {
//            return CGFloat.pi * $0 / 180
//        }
//
//        let gourd   = UIBezierPath()
//        let circle1 = UIBezierPath(arcCenter: CGPoint(x: centerX - radius + arcCenterOffset + 200, y: centerY + 200), radius: radius, startAngle: degree(-30), endAngle: degree(30), clockwise: false)
//        let circle2 = UIBezierPath(arcCenter: CGPoint(x: centerX + radius - arcCenterOffset + 200, y: centerY + 200 ), radius: radius, startAngle: degree(150), endAngle: degree(-150), clockwise: false)
//        gourd.append(circle1)
//        gourd.append(circle2)
//
//        let gourdInverse = UIBezierPath(cgPath: gourd.cgPath)
//        let infiniteRect = UIBezierPath(rect: .infinite)
//        //gourdInverse.append(infiniteRect)
//        infiniteRect.append(gourdInverse)
//
//        context.beginPath()
//        //context.addPath(gourdInverse.cgPath)
//        context.addPath(infiniteRect.cgPath)
//        //context.setShadow(offset: CGSize.zero, blur: 10, color: UIColor.white.cgColor)
//        //context.setFillColor(UIColor(white: 1, alpha: 1).cgColor)
//        //context.setFillColor(UIColor.clear.cgColor)
//        context.fillPath(using: .evenOdd)
//

        // 실제 마크 path
        markedLines.forEach { (line) in
            switch line.type {
            case LineType.Ellipse :
                drawEllipse(context: context, line: line)
                break
            case LineType.Polygon :
                drawPolygon(context: context, line: line)
                break
            case LineType.FreeCurve :
                drawFreeCurve(context: context, line: line)
                break
            case LineType.ClosedCurve :
                drawClosedCurve(context: context, line: line)
                break
            default:
                break
            }
        }
        
    }
    
    fileprivate func getClippingPath(line:Line) -> UIBezierPath {
        var path = UIBezierPath()
        
        switch line.type {
        case LineType.FreeCurve , LineType.ClosedCurve :
            for (i, p) in line.points.enumerated() {
                if i == 0 {
                    path.move(to: p)
                }
                else {
                    path.addLine(to: p)
                }
            }
            path.close()
            
        case LineType.Polygon :
            for (i, p) in line.points.enumerated() {
                if i == 0 {
                    path.move(to: p)
                }
                else {
                    path.addLine(to: p)
                }
            }
            path.close()
            
        case LineType.Ellipse :
            
            let pointx = line.points[0].x
            let pointy = line.points[0].y
            let width = line.points[1].x - line.points[0].x
            let height = line.points[2].y - line.points[1].y
            
            // 타원 정의
            let rect = CGRect(x: pointx, y: pointy, width: width, height: height)
            path = UIBezierPath(ovalIn: rect)
            
        default:
            break
        }
        
        let  dashes: [ CGFloat ] = [ 2.0, 2.0 ]
        path.setLineDash(dashes, count: dashes.count, phase: 0.0)
        
        path.lineWidth = 1.0
        path.lineCapStyle = .round
        UIColor.white.set()
        path.stroke()

        return path
        
    }
    
    fileprivate func addClippingPath(path:UIBezierPath, line:Line) {
        //let path = UIBezierPath()
        
        switch line.type {
        case LineType.FreeCurve , LineType.ClosedCurve :
            for (i, p) in line.points.enumerated() {
                if i == 0 {
                    path.move(to: p)
                }
                else {
                    path.addLine(to: p)
                }
            }
            path.close()
            
        case LineType.Polygon :
            for (i, p) in line.points.enumerated() {
                if i == 0 {
                    path.move(to: p)
                }
                else {
                    path.addLine(to: p)
                }
            }
            path.close()
            
        case LineType.Ellipse :
            
            let pointx = line.points[0].x
            let pointy = line.points[0].y
            let width = line.points[1].x - line.points[0].x
            let height = line.points[2].y - line.points[1].y
            
            // 타원 정의
            let rect = CGRect(x: pointx, y: pointy, width: width, height: height)
            let ovalPath = UIBezierPath(ovalIn: rect)
            path.append(ovalPath)
            
        default:
            break
        }
        
        //return path
        
    }
    
    fileprivate func setClippingPathProperty(path:UIBezierPath) {
        let  dashes: [ CGFloat ] = [ 2.0, 2.0 ]
        path.setLineDash(dashes, count: dashes.count, phase: 0.0)
        
        path.lineWidth = 1.0
        path.lineCapStyle = .round
        UIColor.white.set()
        UIColor.clear.setFill()
        
        path.stroke()

    }
    
    fileprivate func drawFreeCurve(context:CGContext, line:Line) {
        context.setStrokeColor(line.color.cgColor)

        // aslpha값이 0보다 클경우에만 적용
        // 0일 경우에는 선이 보여야 하므로...
        if (line.alpha > 0) {
            context.setAlpha(line.alpha)
        }
        
        context.setLineWidth(CGFloat(line.width))
        context.setLineCap(.round)
        for (i, p) in line.points.enumerated() {
            if i == 0 {
                context.move(to: p)
            }
            else {
                context.addLine(to: p)
            }
        }
        
        context.strokePath()
        context.setAlpha(1.0)   // 알파 초기화

    }
    
    fileprivate func drawClosedCurve(context:CGContext, line:Line) {
        context.setStrokeColor(line.color.cgColor)

        // aslpha값이 0보다 클경우에만 적용
        // 0일 경우에는 선이 보여야 하므로...
        if (line.alpha > 0) {
            context.setFillColor(line.fillcolor.cgColor)
            context.setAlpha(line.alpha)
        }
        
        context.setLineWidth(CGFloat(line.width))
        context.setLineCap(.round)
        for (i, p) in line.points.enumerated() {
            if i == 0 {
                context.move(to: p)
            }
            else {
                context.addLine(to: p)
            }
        }
        context.closePath()
        if (line.alpha > 0) {
            context.fillPath()
        }
        context.strokePath()
        context.setAlpha(1.0)
    }
    

    fileprivate func drawEllipse(context:CGContext, line:Line) {
        
        let pointx = line.points[0].x
        let pointy = line.points[0].y
        let width = line.points[1].x - line.points[0].x
        let height = line.points[2].y - line.points[1].y

        // 타원 정의
        let rect = CGRect(x: pointx, y: pointy, width: width, height: height)
        let ovalPath = UIBezierPath(ovalIn: rect)

        // context에 UIBezierPath의 cgPath를 추가
        context.setStrokeColor(line.color.cgColor)

        // aslpha값이 0보다 클경우에만 적용
        // 0일 경우에는 선이 보여야 하므로...
        if (line.alpha > 0) {
            context.setFillColor(line.fillcolor.cgColor)
            context.setAlpha(line.alpha)
        }
        
        //context.setFillColor(red: 0, green: 0, blue: 0, alpha: 0.2)
        context.setLineWidth(CGFloat(line.width))
        context.setLineCap(.round)
        context.addPath(ovalPath.cgPath)

        if (line.alpha > 0) {
            context.fillPath(using: .winding)
        }

        context.strokePath()
        context.setAlpha(1.0)

    }
    
    fileprivate func drawPolygon(context:CGContext, line:Line) {
        context.setStrokeColor(line.color.cgColor)

        // aslpha값이 0보다 클경우에만 적용
        // 0일 경우에는 선이 보여야 하므로...
        if (line.alpha > 0) {
            context.setFillColor(line.fillcolor.cgColor)
            context.setAlpha(line.alpha)
        }
        
        //context.setFillColor(red: 0, green: 0, blue: 0, alpha: 0.2)
        context.setLineWidth(CGFloat(line.width))
        context.setLineCap(.round)
        for (i, p) in line.points.enumerated() {
            if i == 0 {
                context.move(to: p)
            }
            else {
                context.addLine(to: p)
            }
        }
        if (line.points.count > 2) {
            context.closePath()
        }

        if (line.alpha > 0 && line.points.count > 2) {
            context.fillPath(using: .winding)
        }
        
        context.strokePath()
        context.setAlpha(1.0)

    }
    

    func screenShot(size:CGSize) -> UIImage? {
        let scale = UIScreen.main.scale
        p("screenShot scale : ", scale)
        UIGraphicsBeginImageContextWithOptions(size, false, scale)
        if let context = UIGraphicsGetCurrentContext() {
            self.layer.render(in: context)
            let screenshot = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return screenshot
        }
        return nil
    }
    
    func asImage() -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
    
    func clear(exceptUndo:Bool = false) {
        if (exceptUndo) {
            lines.forEach { (line) in
                undolines.append(line)
            }
        }
        else {
            undolines.removeAll()
        }
        lines.removeAll()
        self.setNeedsDisplay()
    }
    
    func undo() {
        guard let line = lines.popLast() else { return }
        undolines.append(line)
        p("undolines.count : ", undolines.count)
        self.setNeedsDisplay()
    }
    
    func remove(_ index:Int) {
        p("undolines.count : ", undolines.count)
        let line = lines.remove(at: index)
        //p(line)
        undolines.append(line)
        p("undolines.count : ", undolines.count)
        self.setNeedsDisplay()
    }
    
    func redo() {
        guard let line = undolines.popLast() else { return }
        p("undolines.count : ", undolines.count)
        lines.append(line)
        self.setNeedsDisplay()
    }
    
    
}
