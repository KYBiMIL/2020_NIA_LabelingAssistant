//
//  LabelingVC_Download_Thumnail.swift
//  LabelingAssistant4ML
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

var SubImageInfoToDownload:[SubImageInfo] = []

extension LabelingVC {

    class DownloadThumbnailThread: NSObject {
        
        fileprivate var endless = false
        fileprivate var running = false
        
        func runLoop() {
            
            self.running = true
            
            while (endless) {
                if (SubImageInfoToDownload.count > 0) {
                    //let subImageInfoToDownload = SubImageInfoToDownload.removeFirst()
                }
                else {
                    Thread.sleep(forTimeInterval: 0.5)
                }
            }
        }
        
        override init() {
            super.init()
        }
        
        func start() {
            
            if (running) {
                p("이미 다운로드 프로세스가 동작중입니다.")
                return
            }
            
            DispatchQueue.global(qos: .background).async {
                p("DownloadThumbnailThread Start")
                self.endless = true
                self.runLoop()
                DispatchQueue.main.async {
                    p("DownloadThumbnailThread Stop")
                    self.running = false
                }
            }
        }
        
        func stop() {
            if (!running) {
                p("이미 다운로드 프로세스가 정지 상태입니다.")
                return
            }
            endless = false
        }
        
    }

}
