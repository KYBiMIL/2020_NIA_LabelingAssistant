//
//  LabelingVC_MainImage.swift
//  LabelingAssistant4ML
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class MainImageCell: UICollectionViewCell {
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var cellImage: UIImageView!
    
//    internal var befTextColor:UIColor? = UIColor.white
//    internal var befBackColor:UIColor? = UIColor.red
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setdefaultColor()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    internal func setdefaultColor() {
        name.textColor = UIColor.white
        name.backgroundColor = UIColor.darkGray
    }
    
    enum ColorType {
        case basic
        case marked
        case drop
        case selected
    }
    
    func colorType(_ colorType:ColorType) {


        if (colorType == .basic) {
            setdefaultColor()
        }
        else if (colorType == .marked) {
            name.textColor = UIColor.black
            name.backgroundColor = UIColor.yellow
        }
        else if (colorType == .drop) {
            name.textColor = UIColor.black
            name.backgroundColor = UIColor.white
        }
        else if (colorType == .selected) {
//            befTextColor = name.textColor
//            befBackColor = name.backgroundColor
            name.textColor = UIColor.white
            name.backgroundColor = GetTintColor()
        }
        else {
            setdefaultColor()
        }
    }
    
}

extension LabelingVC {

    
    // --------------------------------------------------------------------------
    // 섬네일용 컬렉션뷰 기본 설정
    // --------------------------------------------------------------------------
    func setupMainImageCollectionView() {
        collectionViewMainImage.delegate = self
        collectionViewMainImage.dataSource = self
        collectionViewMainImage.tag = 4
        
        if let layout = collectionViewMainImage.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        
        collectionViewMainImage.backgroundColor = UIColor.white
        
        imageCache.countLimit = 200
        imageCache.totalCostLimit = 0
    }
    

    
    // ================================================================================================================
    // 여기서부터 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================
    func numberOfItemsInSection_MainImage(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func cellForItemAt_MainImage(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IDMainImageCell", for: indexPath as IndexPath) as! MainImageCell
        if (imageArray.count == 0) { return cell }

        cell.backgroundColor = UIColor.black
        
        if (indexPath.item >= imageArray.count) { return cell }
        cell.name.text = imageArray[indexPath.item].row_num?.description
        
        //cell.cellImage.image = cell.cellImage.image

        //cell.cellImage.loadGif(name: "downloading")
        
        if (imageArray[indexPath.item].newMarking!) {
            if (imageArray[indexPath.item].markNum! > 0) {
                cell.colorType(.marked)
            }
            else if (imageArray[indexPath.item].isLabelingDone!) {
                cell.colorType(.marked)
            }
            else if (imageArray[indexPath.item].isDrop! == "Y") {
                cell.colorType(.drop)
            }
            else {
                cell.colorType(.basic)
            }
// 화면에 이미지를 보여주지 않음. 성능문제로.. 20200807
//            if let img = imageArray[indexPath.item].newMarkedImage {
//                cell.cellImage.image = img
//            }
        }
        else {
            if (imageArray[indexPath.item].markNum! > 0) {
                cell.colorType(.marked)
//                if (WorkingProjectMulti == "Y") {
//                    if let file_name = imageArray[indexPath.item].sub_serverLocation {
//                        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
//                        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
//                        cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
//                    }
//                    else {
//                        cell.cellImage.image = nil                   // 디폴트 이미지 세팅
//                    }
//                }
//                else {
//                    if let sourceImagePath = imageArray[indexPath.item].serverLocation {
//                        let aaa = getMarkedImagePathOnServer(sourceImageFullPathOnServer: sourceImagePath, sequence: 0).relativePath
//                        let encoded = aaa.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
//                        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
//                        cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
//                    }
//                }
            }
            else if (imageArray[indexPath.item].isLabelingDone!) {
                cell.colorType(.marked)
//                if let file_name = (WorkingProjectMulti == "Y") ? imageArray[indexPath.item].sub_serverLocation : imageArray[indexPath.item].serverLocation {
//                    let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
//                    let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
//                    cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
//                }
//                else {
//                    //cell.cellImage.image = #imageLiteral(resourceName: "런치스크린이미지")                   // 디폴트 이미지 세팅
//                    cell.cellImage.image = nil                   // 디폴트 이미지 세팅
//                }
            }
            else if (imageArray[indexPath.item].isDrop! == "Y") {
                cell.colorType(.drop)
//                if let file_name = (WorkingProjectMulti == "Y") ? imageArray[indexPath.item].sub_serverLocation : imageArray[indexPath.item].serverLocation {
//                    let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
//                    let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
//                    cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
//                }
//                else {
//                    //cell.cellImage.image = #imageLiteral(resourceName: "런치스크린이미지")                   // 디폴트 이미지 세팅
//                    cell.cellImage.image = nil                   // 디폴트 이미지 세팅
//                }
            }
            else {
                cell.colorType(.basic)
//                if let file_name = (WorkingProjectMulti == "Y") ? imageArray[indexPath.item].sub_serverLocation : imageArray[indexPath.item].serverLocation {
//                    let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
//                    let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
//                    cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
//                }
//                else {
//                    //cell.cellImage.image = #imageLiteral(resourceName: "런치스크린이미지")                   // 디폴트 이미지 세팅
//                    cell.cellImage.image = nil                   // 디폴트 이미지 세팅
//                }
            }
        }
        
        if (currentImageIndex == indexPath.item) {
            cell.colorType(.selected)
            selectedMainImageCellIndexPath = indexPath
        }

        return cell
        
    }
    
    func didSelectItemAt_MainImage(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if (currentImageIndex == indexPath.item) {
            return
        }
        
        var befCellOK = false
        
        if (currentImageIndex >= 0 && currentImageIndex < imageArray.count) {
            if let befIndexPath = selectedMainImageCellIndexPath {
                if let befCell = collectionView.cellForItem(at: befIndexPath) as? MainImageCell {
                    if (imageArray[currentImageIndex].markNum! > 0) {
                        befCell.colorType(.marked)
                    }
                    else if (imageArray[currentImageIndex].isLabelingDone!) {
                        befCell.colorType(.marked)
                    }
                    else if (imageArray[currentImageIndex].isDrop! == "Y") {
                        befCell.colorType(.drop)
                    }
                    else {
                        befCell.colorType(.basic)
                    }
                    befCellOK = true
                }
            }
        }
        else {
            p("Array Index Error : didSelectItemAt_MainImage() number \(currentImageIndex)")
        }

        currentImageIndex = indexPath.item
        let cell = collectionView.cellForItem(at: indexPath) as! MainImageCell
        cell.colorType(.selected)

        selectedMainImageCellIndexPath = indexPath
        loadImageFromURL(index: currentImageIndex)
        
        if (!befCellOK) {
            collectionViewMainImage.reloadData()
        }
    }
    
    func didDeselectItemAt_MainImage(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        //p("---------------------------------------------------------------------------------didDeselectItemAt : \(indexPath.item)")
        return
    }
    
    func collectionViewLayout_MainImage(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionViewLayout_MainImage(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //p("collectionView.frame.width, collectionView.frame.height : \(collectionView.frame.width), \(collectionView.frame.height)")
        if (OrientationValue == .landscape) {
            return CGSize(width: 67, height: collectionView.frame.height - 2)
        }
        else {
            return CGSize(width: 67, height: collectionView.frame.height - 2)
        }
    }
    // ================================================================================================================
    // 여기까지 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================
}
