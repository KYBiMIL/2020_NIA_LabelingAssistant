//
//  MainVC_Gesture.swift
//  LabelingAssistant4ML
//
//  Created by Myeong-Joon Son on 06/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass


// 더블 탭 인터벌 세팅, 기본 인터벌 값을 적용할 경우 더블탭 시간 체크로 인하여 싱글 탭 이벤트 발생 시간이 좀 오래걸림
class UIShortTapGestureRecognizer: UITapGestureRecognizer {
    
    //anything below 0.3 may cause doubleTap to be inaccessible by many users
    let tapMaxDelay: Double = 0.3 // 0.26 seconds
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesBegan(touches, with: event)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + tapMaxDelay) { [weak self] in
            if self?.state != UIGestureRecognizer.State.recognized {
                self?.state = UIGestureRecognizer.State.failed
            }
        }
    }
}

extension LabelingVC {
    
    func initGesture() {
        
        setScrollViewPropertyForImage()

        // panning
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(imagePanned(_:)))

        // 1 touch 1 tap
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped(_:)))
        tapGesture!.numberOfTouchesRequired = 1
        tapGesture!.numberOfTapsRequired = 1
        
        // 1 touch 2 taps
        doubleTapGesture = UIShortTapGestureRecognizer(target: self, action: #selector(scrollImageDoubleTapped(_:)))
        doubleTapGesture!.numberOfTouchesRequired = 1
        doubleTapGesture!.numberOfTapsRequired = 2
        ScrollImage.addGestureRecognizer(doubleTapGesture!)

        tapGesture!.require(toFail: doubleTapGesture!)  // 더블 탭 fail일 경우 싱글 탭 적용, 이렇게 하지 않으면 싱글 및 더블 탭 모두 이벤트 발생

        // 2 touches 1 tap
        tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(imageTapped2(_:)))
        tapGesture2!.numberOfTouchesRequired = 2
        tapGesture2!.numberOfTapsRequired = 1
        ScrollImage.addGestureRecognizer(tapGesture2!)
        
        // long press
        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(imageLongPressed(_:)))
        longPressGesture!.minimumPressDuration = 0.3
        longPressGesture!.allowableMovement = 15 // 15 points
        longPressGesture!.delaysTouchesBegan = true
        
        // long press : pan 제스처가 지연되는 현상이 발생하므로 대신에 짧은 long press로 대신함
        longPressGestureForNodelayPan = UILongPressGestureRecognizer(target: self, action: #selector(imagePanned(_:)))
        longPressGestureForNodelayPan!.minimumPressDuration = 0.1
        longPressGesture!.allowableMovement = 15 // 15 points
//        longPressGesture!.delaysTouchesBegan = true
//        longPressGesture!.cancelsTouchesInView = false
        longPressGesture!.delaysTouchesEnded = true

        //setupSwipeGestureRecognizer()
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage로부터 모든 마킹용 제스처 제거
    //--------------------------------------------------------------------------------
    func removeGestureForMarking() {
        EditingImage.removeGestureRecognizer(panGesture!)
        EditingImage.removeGestureRecognizer(longPressGesture!)
        EditingImage.removeGestureRecognizer(longPressGestureForNodelayPan!)
        EditingImage.removeGestureRecognizer(tapGesture!)
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage 뷰에 마킹용 제스처 설정
    //--------------------------------------------------------------------------------
    func addGestureForMarking(lineType:LineType) {
        
        removeGestureForMarking()
        
        switch lineType {
        case .ClosedCurve, .FreeCurve:
            //EditingImage.addGestureRecognizer(panGesture!)
            EditingImage.addGestureRecognizer(longPressGestureForNodelayPan!)
            break
        case .Eraser:
            EditingImage.addGestureRecognizer(longPressGestureForNodelayPan!)
            break
        case .Ellipse:
            EditingImage.addGestureRecognizer(panGesture!)
            //EditingImage.addGestureRecognizer(longPressGestureForNodelayPan!)  // tap인지 long인지 체크하는 것 때문에 여기서는 사용안하고 그냥 pan 제스처 사용
            EditingImage.addGestureRecognizer(tapGesture!)
            break
        case .Polygon:
            EditingImage.addGestureRecognizer(panGesture!) // long press 제스처를 사용해야 하므로 longPressGestureForNodelayPan를 사용하지 않고 panGesture를 사용함
            EditingImage.addGestureRecognizer(tapGesture!)
            EditingImage.addGestureRecognizer(longPressGesture!)
            break
        }
    }
    
//    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        //super.touchesBegan(touches, with: event)
//
//        let touch: UITouch = touches.first!
//
//        p(touch.view.debugDescription)
//
//        if (touch.view == EditingImage){
//            p("touchesBegan | This is an EditingImage")
//        }else{
//            p("touchesBegan | This is not an EditingImage")
//        }
//    }
//
//    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
//        //super.touchesMoved(touches, with: event)
//
//        let touch: UITouch = touches.first!
//
//        if (touch.view == EditingImage){
//            p("touchesMoved | This is an EditingImage")
//        }else{
//            p("touchesMoved | This is not an EditingImage")
//        }
//    }
//
//    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
//        //super.touchesMoved(touches, with: event)
//
//        let touch: UITouch = touches.first!
//
//        if (touch.view == EditingImage){
//            p("touchesEnded | This is an EditingImage")
//        }else{
//            p("touchesEnded | This is not an EditingImage")
//        }
//    }
    
//    func imageTouchesBegan() {
//        p("imageTouchesBegan")
//    }
//    func imageTouchesMoved() {
//        p("imageTouchesMoved")
//    }
//    func imageTouchesEnded() {
//        p("imageTouchesEnded")
//    }
//    func imageTouchesCanceled() {
//        p("imageTouchesCanceled")
//    }
    
    //--------------------------------------------------------------------------------
    // 1 touch 1 tap
    //--------------------------------------------------------------------------------
    @objc func imageTapped(_ gesture: UITapGestureRecognizer) {
        drawLineTapped(gesture: gesture)
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage 2 touch 1 tap
    //--------------------------------------------------------------------------------
    @objc func imageTapped2(_ gesture: UITapGestureRecognizer) {
        ScrollImage.zoomScale = 1
    }
    
    //--------------------------------------------------------------------------------
    // scrollImage 1 touch 2 tap
    //--------------------------------------------------------------------------------
    @objc func scrollImageDoubleTapped(_ gesture: UITapGestureRecognizer) {
        showReferImageScreen()
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage 1 touch long press
    //--------------------------------------------------------------------------------
    @objc func imageLongPressed(_ gesture: UILongPressGestureRecognizer) {
        p("imageLongPressed: ", gesture.state.rawValue)
        switch gesture.state {
        case .began:
            drawLineLongPress(gesture: gesture)
            p("imageLongPressed Began: ", gesture.state.rawValue)
            break
        case .ended, .cancelled, .failed:
            p("imageLongPressed Ended: ", gesture.state.rawValue)
            break
        default:
            p("imageLongPressed etc. : ", gesture.state.rawValue)
            break
        }
    }
    
    //--------------------------------------------------------------------------------
    // EditingImage panning
    //--------------------------------------------------------------------------------
    @objc func imagePanned(_ gesture: UIPanGestureRecognizer) {
        
        //p("imagePanned start -------------------- ")
        struct Temp { static var numberOfTouchesWhenBegan = 0 }
        
        if (gesture.state != .changed) {
            //p("imagePanned state : ", gesture.state.rawValue)
        }
        
        if (gesture.state == .began) {
            Temp.numberOfTouchesWhenBegan = gesture.numberOfTouches
            p("------ \(gesture.location(in: EditingImage)) : imagePanned .began")
            drawLineBegan(gesture: gesture)
        }
        if (gesture.state == .changed) {
            //p("------ \(gesture.location(in: EditingImage)) : imagePanned .changed")
            drawLineMoved(gesture: gesture)
        }
        if (gesture.state == .cancelled) {
            p("------ \(gesture.location(in: EditingImage)) : imagePanned .cancelled")
        }
        if (gesture.state == .failed) {
            p("------ \(gesture.location(in: EditingImage)) : imagePanned .failed")
        }
        if (gesture.state == .possible) {
            p("------ \(gesture.location(in: EditingImage)) : imagePanned .possible")
        }
        if (gesture.state == .recognized) {
            p("------ \(gesture.location(in: EditingImage)) : imagePanned .recognized")
        }
        if (gesture.state == .ended) {
            p("------ \(gesture.location(in: EditingImage)) : imagePanned .ended")
            drawLineEnded(gesture: gesture)
        }
        
    }
    
    // 새로운 다음 이미지, 이전 이미지 가져오기
    func slideImage(gesture: UIPanGestureRecognizer) {
        p("gesture type : slideImage")
    }
    
    //--------------------------------------------------------------------------------
    // Pinch Gesture Set
    //--------------------------------------------------------------------------------
    func setupPinchGestureRecognizer() {
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(imagePinched(_:)))
        EditingImage.addGestureRecognizer(pinchGesture)
    }
    
    @objc func imagePinched(_ gesture:UIPinchGestureRecognizer) {
        zoomImage(gesture: gesture)
    }
    
    func zoomImage(gesture: UIPinchGestureRecognizer) {
        if(gesture.state == .began) {
            lastScale = gesture.scale
        }
        
        if (gesture.state == .began || gesture.state == .changed) {
            let currentScale = gesture.view!.layer.value(forKeyPath:"transform.scale")! as! CGFloat
            let kMaxScale:CGFloat = 6.0
            let kMinScale:CGFloat = 1.0
            var newScale = 1 -  (lastScale - gesture.scale)
            newScale = min(newScale, kMaxScale / currentScale)
            newScale = max(newScale, kMinScale / currentScale)
            let transform = (gesture.view?.transform)!.scaledBy(x: newScale, y: newScale);
            gesture.view?.transform = transform
            lastScale = gesture.scale
        }
    }
    
    //--------------------------------------------------------------------------------
    // Swipe Gesture Set
    //--------------------------------------------------------------------------------
    func setupSwipeGestureRecognizer() {
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeLeft.direction = .left
        self.EditingImage.addGestureRecognizer(swipeLeft)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeRight.direction = .right
        self.EditingImage.addGestureRecognizer(swipeRight)
        
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeUp.direction = .up
        self.EditingImage.addGestureRecognizer(swipeUp)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(imageSwiped(_:)))
        swipeDown.direction = .down
        self.EditingImage.addGestureRecognizer(swipeDown)
    }
    
    @objc func imageSwiped(_ gesture: UISwipeGestureRecognizer) -> Void {
        if gesture.direction == UISwipeGestureRecognizer.Direction.right {
            p("Swipe Right")
        }
        else if gesture.direction == UISwipeGestureRecognizer.Direction.left {
            p("Swipe Left")
        }
        else if gesture.direction == UISwipeGestureRecognizer.Direction.up {
            p("Swipe Up")
        }
        else if gesture.direction == UISwipeGestureRecognizer.Direction.down {
            p("Swipe Down")
        }
    }
}
