//
//  LabelingVC_Save.swift
//  LabelingAssistant4ML
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    // --------------------------------------------------------------------------------------
    // save 버튼이 클릭되었을때 라벨링 결과와 마킹된 마크 이미지들을 저장
    // --------------------------------------------------------------------------------------
    func saveLabelingResultAndMark() {
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        
        if (saveLabelingResult()) {
            
            setLabelingResultInfo() // 20200730 서버에 저장 성공시에만 저장
            setProgressValue()
            
            let imageId = imageArray[currentImageIndex].id!
            
            if (markUpdated) {
                saveMarkedImageInScrollImage(scrollView: ScrollImage, imageView: EditingImage, imageId: imageId)
            }
            
            // 마지막에 저장했던 이미지를 유저디폴트에 저장
            UserDefaults.standard.set(imageId, forKey: DefaultKey_LastLabelingImageId)
            LastLabelingImageId = imageId

            self.view.showToast(toastMessage: " 저장 완료...  ", duration: 0.5)
            
            // 저장 후 바로 다음 이미지를 가져옴. 20200702 막음. 다시 풀음 20200704
            if (WorkingProjectMulti != "Y") {
                arrowRightClick()
            }
            
        }
        else {
            if (LastURLErrorMessage != "") {
                let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
                let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
                    //self.dismiss(animated: true, completion: nil)
                    alertProgressNoAction.dismiss(animated: true, completion: nil)
                })
                alertProgressNoAction.addAction(otherAction)
                self.present(alertProgressNoAction, animated: false, completion: nil)
            }
        }
        
        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
        
    }
    
    // --------------------------------------------------------------------------------------
    // 라벨링 여부 및 결과를 해당 변수에 저장
    // --------------------------------------------------------------------------------------
    func setLabelingResultInfo() {
        
        imageArray[currentImageIndex].isLabelingDone = true
        imageArray[currentImageIndex].labelingResult.removeAll()
        
        var labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 0;
        labelingLocationResult.label_cd = getLastSelectedIndex(0);
        imageArray[currentImageIndex].labelingResult.append(labelingLocationResult);
        
        labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 1;
        labelingLocationResult.label_cd = getLastSelectedIndex(1);
        imageArray[currentImageIndex].labelingResult.append(labelingLocationResult);
        
    }
    
    func setLabelingResultInfoByDrop(isDrop:Bool) {
        
        imageArray[currentImageIndex].isLabelingDone = false
        imageArray[currentImageIndex].isDrop = isDrop ? "Y" : "N"
        imageArray[currentImageIndex].labelingResult.removeAll()
        
        var labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 0;
        labelingLocationResult.label_cd = -1;
        imageArray[currentImageIndex].labelingResult.append(labelingLocationResult);
        
        labelingLocationResult = LabelingLocationResult()
        labelingLocationResult.target_cd = 1;
        labelingLocationResult.label_cd = -1;
        imageArray[currentImageIndex].labelingResult.append(labelingLocationResult);
        
    }
    
    // --------------------------------------------------------------------------------------
    // 스크롤이미지 안에 마킹된 마크들을 파일로 저장하고 upload해야 함
    // --------------------------------------------------------------------------------------
    func saveMarkedImageInScrollImage(scrollView:UIScrollView, imageView:UIImageView, imageId:String) {
        
        let beforeZoomScale = scrollView.zoomScale
        let beforeContentOffset = scrollView.contentOffset
        scrollView.zoomScale = 1.0
        
        saveMarkedImage(imageView:imageView, imageId: imageId)
        
        // 원래의 zoom 크기와 offset으로 원복
        scrollView.zoomScale = beforeZoomScale
        scrollView.contentOffset = beforeContentOffset
        
    }
    

}
