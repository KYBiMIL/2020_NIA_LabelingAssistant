//
//  LabelingVC_CV.swift
//  LabelingAssistant4ML
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class LabelBottomCell: UICollectionViewCell {
    @IBOutlet var textLabel: UILabel!
}

extension LabelingVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    // MARK: - UICollectionViewDataSource protocol
    func numberOfSectionsInCollectionView(collectionView: UICollectionView!) -> Int {
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return 1
        }
        else if(collectionView.tag == 4) {
            return 1
        }
        else if(collectionView.tag == 5) {
            return 1
        }
        // ----------------------------------------------------------------------------------------------
        // 하단 라벨 목록이면~~~
        // ----------------------------------------------------------------------------------------------
        return 1
    }

    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return numberOfItemsInSection_Thumbnail(collectionView, numberOfItemsInSection: section)
        }
        else if(collectionView.tag == 4) {
            return numberOfItemsInSection_MainImage(collectionView, numberOfItemsInSection: section)
        }
        else if(collectionView.tag == 5) {
            return numberOfItemsInSection_Group(collectionView, numberOfItemsInSection: section)
        }

        // ----------------------------------------------------------------------------------------------
        // 하단 라벨 목록이면~~~
        // ----------------------------------------------------------------------------------------------
        //p("numberOfItemsInSection:", LabelList.getLabelCount(location: collectionView.tag))
        return LabelList.getLabelCount(location: collectionView.tag)
        
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return cellForItemAt_Thumbnail(collectionView, cellForItemAt: indexPath)
        }
        else if(collectionView.tag == 4) {
            return cellForItemAt_MainImage(collectionView, cellForItemAt: indexPath)
        }
        else if(collectionView.tag == 5) {
            return cellForItemAt_Group(collectionView, cellForItemAt: indexPath)
        }

        // ----------------------------------------------------------------------------------------------
        // 하단 라벨 목록이면~~~
        // ----------------------------------------------------------------------------------------------
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LabelCollectionViewCell", for: indexPath as IndexPath) as! LabelBottomCell
        
        // Use the outlet in our custom class to get a reference to the UILabel in the cell
//        let label = LabelList.getLabelText(location: collectionView.tag)[indexPath.item]
//        cell.textLabel.text = label
        
        let label = LabelList.getLabelText(location: collectionView.tag)[indexPath.item]
        let count = mainImageList.countByLabel(target_cd: collectionView.tag, label_cd: indexPath.item)
        cell.textLabel!.text = "\(label)\n(\(count))"

        // property mapping
        cell.textLabel.frame = CGRect(x: 0, y: 0, width: cell.frame.width, height: cell.frame.height)
        cell.textLabel.lineBreakMode = NSLineBreakMode.byCharWrapping
        cell.textLabel.numberOfLines = 2
        cell.textLabel.textAlignment = .center
        
        cell.backgroundColor = defaultCellBackgroundColor // make cell more visible in our example project
        
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 0.3
        
        if (getLastSelectedIndex(collectionView.tag) == indexPath.item) {
            cell.textLabel.textColor = selectedCellTextColor
            cell.backgroundColor = GetTintColor()
            
            // 리뷰 모드일 경우에는 선택된 라벨의 글씨 색상을 변경
            if (IsReviewMode) {
                if ((collectionView.tag == 0 &&  indexPath.item == LeftIndexOnReviewMode) ||
                    (collectionView.tag == 1 &&  indexPath.item == RightIndexOnReviewMode)) {
                    if (GetTintColor() == UIColor.orange) {
                        cell.textLabel.textColor = UIColor.blue
                    }
                    else {
                        cell.textLabel.textColor = UIColor.yellow
                    }
                }
            }
            
        }
        else {
            cell.textLabel.textColor = defaultCellTextColor
            cell.backgroundColor = defaultCellBackgroundColor
            
            // 리뷰 모드일 경우에는 선택된 라벨의 글씨 색상을 변경
            if (IsReviewMode) {
                if ((collectionView.tag == 0 &&  indexPath.item == LeftIndexOnReviewMode) ||
                    (collectionView.tag == 1 &&  indexPath.item == RightIndexOnReviewMode)) {
                    cell.textLabel.textColor = UIColor.blue
                }
            }
            
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            didSelectItemAt_Thumbnail(collectionView, didSelectItemAt: indexPath)
            return
        }
        else if(collectionView.tag == 4) {
            didSelectItemAt_MainImage(collectionView, didSelectItemAt: indexPath)
            return
        }
        else if(collectionView.tag == 5) {
            didSelectItemAt_Group(collectionView, didSelectItemAt: indexPath)
            return
        }

        // ----------------------------------------------------------------------------------------------
        // 하단 라벨 목록이면~~~
        // ----------------------------------------------------------------------------------------------
        //p("didSelectItemAt:", indexPath.item)
        
        setLastSelectedIndex(collectionView.tag, indexPath.item)
        checkSaveButtonShow()
        collectionView.reloadData()
        tableViewLabelLeft.reloadData()

    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        if(collectionView.tag == 4) {
            didDeselectItemAt_MainImage(collectionView, didDeselectItemAt: indexPath)
            return
        }
        return
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return 1
        }
        else if(collectionView.tag == 4) {
            return 1
        }
        else if(collectionView.tag == 5) {
            return 1
        }

        // ----------------------------------------------------------------------------------------------
        // 하단 라벨 목록이면~~~
        // ----------------------------------------------------------------------------------------------
        return 0

    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {

        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return collectionViewLayout_Thumbnail(collectionView, layout: collectionViewLayout, minimumInteritemSpacingForSectionAt: section)
        }
        else if(collectionView.tag == 4) {
            return collectionViewLayout_MainImage(collectionView, layout: collectionViewLayout, minimumInteritemSpacingForSectionAt: section)
        }
        else if(collectionView.tag == 5) {
            return collectionViewLayout_Group(collectionView, layout: collectionViewLayout, minimumInteritemSpacingForSectionAt: section)
        }

        // ----------------------------------------------------------------------------------------------
        // 하단 라벨 목록이면~~~
        // ----------------------------------------------------------------------------------------------
        return 0

    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        // ----------------------------------------------------------------------------------------------
        // 섬네일이면~~~
        // ----------------------------------------------------------------------------------------------
        if (collectionView.tag == 3) {
            return collectionViewLayout_Thumbnail(collectionView, layout: collectionViewLayout, sizeForItemAt: indexPath)
        }
        else if(collectionView.tag == 4) {
            return collectionViewLayout_MainImage(collectionView, layout: collectionViewLayout, sizeForItemAt: indexPath)
        }
        else if(collectionView.tag == 5) {
            return collectionViewLayout_Group(collectionView, layout: collectionViewLayout, sizeForItemAt: indexPath)
        }

        // ----------------------------------------------------------------------------------------------
        // 하단 라벨 목록이면~~~
        // ----------------------------------------------------------------------------------------------
        let width  = (collectionView.frame.width)/CGFloat(LabelList.getLabelCount(location: collectionView.tag))
        return CGSize(width: width, height: collectionView.frame.height)
        
    }
    
//    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
//        let cell = collectionView.cellForItem(at: indexPath)
//        p("didHighlightItemAt:", indexPath.item, indexPath.row)
//        cell?.backgroundColor = UIColor.red
//    }
//
//    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
//        let cell = collectionView.cellForItem(at: indexPath)
//        p("didUnhighlightItemAt:", indexPath.item, indexPath.row)
//        cell?.backgroundColor = UIColor.cyan
//    }

}
