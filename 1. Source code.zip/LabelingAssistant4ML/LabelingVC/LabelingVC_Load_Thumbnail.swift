//
//  LabelingVC_Load_Thumbnail.swift
//  LabelingAssistant4ML
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class SubImageInfo {
    var row_num:Int?                    // row num
    var sub_image_id:String?            // 하위 이미지 ID
    var sub_server_location:String?     // 서버 파일 위치 및 이름
    var mark_num:Int?
    var group:String?
    var newMarking:Bool?
    var newMarkedImage:UIImage?
}

class SubImageList {
    var images:[SubImageInfo] = [SubImageInfo]()
    var count:Int {
        get {
            return images.count
        }
    }
    
    var groupList:[String] {
        get {
            var grouplist:[String] = [String]()
            var exist = false
            for image in images {
                exist = false
                for name in grouplist {
                    if (name == image.group) {
                        exist = true
                    }
                }
                if (!exist) {
                    grouplist.append(image.group!)
                }
            }
            return grouplist
        }
    }
    
    func imagesByGroup(group:String) -> [SubImageInfo] {
        var subImageList: [SubImageInfo] = []
        for image in images {
            if (image.group == group) {
                subImageList.append(image)
            }
        }
        return subImageList
    }
    
    func append(subImageInfo:SubImageInfo) {
        images.append(subImageInfo)
    }
    
    func append(subImageList:[SubImageInfo]) {
        images.append(contentsOf: subImageList)
    }
    
    func removeAll() {
        images.removeAll()
    }
    
}

extension LabelingVC {

    // --------------------------------------------------------------------------
    // 섬네일용 컬렉션뷰 기본 설정
    // --------------------------------------------------------------------------
    func setupImageCollectionView() {
        collectionViewThumbnail.delegate = self
        collectionViewThumbnail.dataSource = self
        collectionViewThumbnail.tag = 3
        
        if let layout = collectionViewThumbnail.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        
        collectionViewThumbnail.backgroundColor = UIColor.white
        //imageCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "ImageCell")
        
        imageCache.countLimit = 200
        imageCache.totalCostLimit = 0
    }
    
    // --------------------------------------------------------------------------
    // 섬네일용 이미지 로딩
    // --------------------------------------------------------------------------
    func loadSubImageList() {
        
        subImageList.removeAll()
        subImageArray.removeAll()
        selectedGroupIndex = -1
        
        //resetSubImageList()
        last_row_num = -1
        sub_image_count = 0
        selectedSubImageRowNum = -1
        
        if (getSubImageList()) {
            while (last_row_num >= 0 && last_row_num < sub_image_count) {
                if (getSubImageList()) {
                    continue
                }
                else {
                    p("error occur")
                }
            }
            
            //collectionViewThumbnail.reloadData() 20200808
            
            if (subImageList.count == 0) {
                self.view.showToast(toastMessage: "멀티 레이어용 이미지가 등록되어 있지 않습니다.", duration: 1.5)
                return
            }
            else {
                selectedGroupIndex = 0
                selectedGroupName = subImageList.groupList[0]
                collectionViewThumbGroup.reloadData()
                
                subImageArray = subImageList.imagesByGroup(group: selectedGroupName)
                collectionViewThumbnail.reloadData()
                
                selectedSubImageRowNum = 0
                
                if (OrientationValue == .landscape) {
                    collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
                    // ------ 썸네일뷰를 가로 모드에서 좌측위치에 아래로 길게 배열하기 위해서는 아래를 풀고 위를 막음
                    //                collectionViewThumbnail.scrollToItem(at: IndexPath(item: centerItemNo, section: 0), at: UICollectionView.ScrollPosition.centeredVertically, animated: false)
                }
                else {
                    collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
                }
            }
//            else {
//                if (subImageList.count > 20) {
//
//                    // 썸네일의 중간으로 이동하는 것을 막음. 20200807
//                    //let centerItemNo:Int = subImageList.count / 2
//                    let centerItemNo:Int = 0
//
//                    selectedSubImageRowNum = centerItemNo
//
//                    if (OrientationValue == .landscape) {
//                        collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
//                        // ------ 썸네일뷰를 가로 모드에서 좌측위치에 아래로 길게 배열하기 위해서는 아래를 풀고 위를 막음
//                        //                collectionViewThumbnail.scrollToItem(at: IndexPath(item: centerItemNo, section: 0), at: UICollectionView.ScrollPosition.centeredVertically, animated: false)
//                    }
//                    else {
//                        collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
//                    }
//                }
//            }
        }
        else {
            p("error occur")
        }
        
    }
    
    func loadSubImageOneFromUrl(subImageInfo:SubImageInfo) {
        
        if (currentImageIndex < 0 || currentImageIndex >= imageArray.count) {
            p("Array Index Error : loadSubImageOneFromUrl() number \(currentImageIndex)")
            return
        }
        
        guard let sourceImageFullPath = imageArray[currentImageIndex].serverLocation,
            let subImageFullPath = subImageInfo.sub_server_location else { return }
        
        existImage = false
        noticeClearMark = false
        
        savedSourceImageUrlPath = downloadSourceImage(subImageInfo.sub_image_id!, subImageFullPath)
        
        if let mark_num = subImageInfo.mark_num {
            loadedMarkNum = mark_num
            markCountLabel.text = "\(loadedMarkNum)개"
        }
        else {
            loadedMarkNum = 0
            markCountLabel.text = "0개"
        }

        if (imageArray[currentImageIndex].isLabelingDone! && loadedMarkNum > 0) {
            
            let markedLocation = getMarkedImagePathOnServer(sourceImageFullPathOnServer: sourceImageFullPath, sourceSubImageFullPathOnServer: subImageFullPath, sequence: 0)
            savedMarkedImageUrlPath = downloadMarkedImage(subImageInfo.sub_image_id!, URL(fileURLWithPath: markedLocation.relativePath))
            
            if savedMarkedImageUrlPath == nil {
                if savedSourceImageUrlPath == nil {
                    existImage = false
                    realImage = #imageLiteral(resourceName: "ImageNotRegistered")                   // 디폴트 이미지 세팅
                    showNotRegisterdMessage()
                }
                else {
                    existImage = true
                    //EditingImage.isUserInteractionEnabled = false
                    noticeClearMark = true
                    realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)
                }
            }
            else {
                existImage = true
                //EditingImage.isUserInteractionEnabled = false
                noticeClearMark = true
                realImage = UIImage(contentsOfFile: savedMarkedImageUrlPath!)
            }
            
        } // if절, 완료이미지
        else {
            if savedSourceImageUrlPath == nil {
                existImage = false
                realImage = #imageLiteral(resourceName: "ImageNotRegistered")                   // 디폴트 이미지 세팅
                showNotRegisterdMessage()
            }
            else {
                existImage = true
                realImage = UIImage(contentsOfFile: savedSourceImageUrlPath!)
            }
        } // else 절, 미완료 이미지
        
        realImageWHRatio = Float(realImage!.size.width / realImage!.size.height)
        //p("Image real size : ", realImage!.size.width, ",", realImage!.size.height, ",", realImageWHRatio!)
        EditingImage.image = realImage
        originalImage = realImage
        
    }
    
    // -----------------------------------------------------------------------------
    // 서버 상의 마킹 이미지 저장 path 설정
    // 멀티레이어의 경우에는 source 이미지와 sub 이미지의 path 두개의 정보를 받음
    // -----------------------------------------------------------------------------
    func getMarkedImagePathOnServer(sourceImageFullPathOnServer:String, sourceSubImageFullPathOnServer:String, sequence:Int) -> URL {
        
        let sourceImageFullPathUrl = URL(fileURLWithPath: sourceImageFullPathOnServer)
        var markedImageDirectroyUrl = sourceImageFullPathUrl.deletingLastPathComponent()                                    // 파일명 제거
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("marked")                                  // marked 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(WorkingLabelingOrder)")                 // 차수 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(imageArray[currentImageIndex].id!)")    // ImageID(멀티레이어 메인 ID) 추가
        
        let sourceSubImageFullPathUrl = URL(fileURLWithPath: sourceSubImageFullPathOnServer)
        let sourceSubImageNameUrl = sourceSubImageFullPathUrl.deletingPathExtension().lastPathComponent
        
        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@%03d.jpg", sourceSubImageNameUrl, markedImageNameSuffix, sequence))
        
        //p("getMarkedImagePathOnServer : \(markedImageFullPathUrl.path)")
        return markedImageFullPathUrl
    }
    
    // -----------------------------------------------------------------------------
    // 서버 상의 마킹 이미지 저장 path 설정
    // 싱글레이어의 경우에는 source 이미지 정보만 받음
    // -----------------------------------------------------------------------------
    func getMarkedImagePathOnServer(sourceImageFullPathOnServer:String, sequence:Int) -> URL {
        
        let sourceImageFullPathUrl = URL(fileURLWithPath: sourceImageFullPathOnServer)
        let sourceImageNameUrl = sourceImageFullPathUrl.deletingPathExtension().lastPathComponent
        var markedImageDirectroyUrl = sourceImageFullPathUrl.deletingLastPathComponent()                                    // 파일명 제거
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("marked")                                  // marked 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent(LoginID)                                   // LoginID 추가
        markedImageDirectroyUrl = markedImageDirectroyUrl.appendingPathComponent("\(WorkingLabelingOrder)")                 // 차수 추가
        
        let markedImageFullPathUrl = markedImageDirectroyUrl.appendingPathComponent(String(format: "%@%@%03d.jpg", sourceImageNameUrl, markedImageNameSuffix, sequence))
        
        //p("getMarkedImagePathOnServer : \(markedImageFullPathUrl.path)")
        return markedImageFullPathUrl
    }
    
    func getMarkedImageDirectoryOnServer(serverSourceImagePath:String, imageId:String) -> URL {
        
        let serverSourceImageURL = URL(fileURLWithPath: serverSourceImagePath)
        let serverSourceImageDir = serverSourceImageURL.deletingLastPathComponent()             // 마지막 path를 제거
        var serverMarkedImageDir = serverSourceImageDir.appendingPathComponent("marked")        // marked 추가
        serverMarkedImageDir = serverMarkedImageDir.appendingPathComponent(LoginID)             // 유저 추가
        serverMarkedImageDir = serverMarkedImageDir.appendingPathComponent("\(WorkingLabelingOrder)")   // 차수 추가
        if (WorkingProjectMulti == "Y") {
            serverMarkedImageDir = serverMarkedImageDir.appendingPathComponent("\(imageId)")    // 멀티일 경우에는 imageid 디렉토리를 추가
        }
        return serverMarkedImageDir
    }
    
}
