//
//  Contains.swift
//  LabelingAssistant4ML
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

// -----------------------------------------------------------
// 꼭지점 어레이를 이용하여 다각형 내에 특정 포인트가 존재하는지 체크
// 꼭지점으로 다각형을 UIBezierPath로 그린 이후에 체크
// -----------------------------------------------------------
func containsInPolygon(points: [CGPoint], point: CGPoint) -> Bool {
    if points.count <= 1 {
        return false //or if first point = test -> return true
    }
    
    let p = UIBezierPath()
    let firstPoint = points[0] as CGPoint
    
    p.move(to: firstPoint)
    
    for index in 1...points.count-1 {
        p.addLine(to: points[index] as CGPoint)
    }
    
    p.close()
    
    return p.contains(point)
}

// -----------------------------------------------------------
// 특정 도형을 이루고 있는 선들중에 2포인트를 잇는 선과 교차되는 선이 있는지 체크
// 교차되는 선이 있는 경우 해당 도형을 삭제하기 위해 만듬
// -----------------------------------------------------------
func isCrossWithSomeLine(points: [CGPoint], point1: CGPoint, point2:CGPoint) -> Bool {
    if points.count <= 1 {
        return false //or if first point = test -> return true
    }

    var befPoint:CGPoint?
    
    for (index, point) in points.enumerated() {
        if (index > 0) {
            if (existIntersectionOfTwoLines(line1: (befPoint!, point), line2: (point1, point2))) {
                return true
            }
        }
        befPoint = point
    }

    return false
}


// -----------------------------------------------------------
// 2개 선이 교차하는지를 체크하는 함수
// -----------------------------------------------------------
func existIntersectionOfTwoLines(line1: (a: CGPoint, b: CGPoint), line2: (a: CGPoint, b: CGPoint)) -> Bool {
    
    let distance = (line1.b.x - line1.a.x) * (line2.b.y - line2.a.y) - (line1.b.y - line1.a.y) * (line2.b.x - line2.a.x)
    if distance == 0 {
        //print("error, parallel lines")
        return false
    }
    
    let u = ((line2.a.x - line1.a.x) * (line2.b.y - line2.a.y) - (line2.a.y - line1.a.y) * (line2.b.x - line2.a.x)) / distance
    let v = ((line2.a.x - line1.a.x) * (line1.b.y - line1.a.y) - (line2.a.y - line1.a.y) * (line1.b.x - line1.a.x)) / distance
    
    if (u < 0.0 || u > 1.0) {
        //print("error, intersection not inside line1")
        return false
    }
    if (v < 0.0 || v > 1.0) {
        //print("error, intersection not inside line2")
        return false
    }
    
    return true
}

// -----------------------------------------------------------
// 직사각형 내에 그려진 타원 내에 특정 포인트가 존재하는지 체크
// 직사각형내에 UIBezierPath로 타원을 그린 후에 체크
// -----------------------------------------------------------
func containsInEllipse(frame: CGRect, point: CGPoint) -> Bool {
    let p = UIBezierPath(ovalIn: frame)
    return p.contains(point)
}

