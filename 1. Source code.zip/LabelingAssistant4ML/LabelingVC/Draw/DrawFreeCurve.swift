//
//  drawFreeCurve.swift
//  testSaveImage
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

//    func panGestureBegan_FreeCurve(point:CGPoint) {
//
//        if (canvas.isDrawing) { return }
//        let width = lineType == .FreeCurve ? lineWidth : 2.0
//        let alpha = lineType == .FreeCurve ? 0.3 : 0.0
//        var line = Line(isClip: false, type: lineType, width: width, color: lineColor, fillcolor: UIColor.white, alpha: CGFloat(alpha), points: []) // 선의 point 배열 생성
//        
//        line.points.append(point)                                       // 선에 시작 포인트 추가
//        canvas.lines.append(line)                                       // 선 배열에 선을 추가
//        
//        canvas.isDrawing = true                                         // 선 그리기 시작
//        
//    }
//
//    func panGestureMoved_FreeCurve(point:CGPoint) {
//        
//        if (!canvas.isDrawing) { return }                               // 선 그리기 상태가 아니면 return
//
//        guard var lastLine = canvas.lines.popLast() else { return }     // 선 배열에서 마지막 선을 pop
//        lastLine.points.append(point)                                   // 가져온 선에 point 추가
//        canvas.lines.append(lastLine)                                   // 다시 선 배열에 추가
//        //p("---- lines count :", canvas.lines.count)
//        
//        canvas.setNeedsDisplay()                                        // 화면 상에 표시하기 위하여 호출(draw 함수가 호출됨)
//
//    }
//    
//    func panGestureEnded_FreeCurve(point:CGPoint) {
//        if (!canvas.isDrawing) { return }                               // 선 그리기 상태가 아니면 return
//        canvas.isDrawing = false                                        // 선 그리기 상태 해제
//
//        if (lineType == .ClosedCurve) {
//            guard var lastLine = canvas.lines.popLast() else { return }     // 선 배열에서 마지막 선을 pop
//            lastLine.fillcolor = lastLine.color
//            lastLine.alpha = 0.3
//            if (lineColor == EnumDrawingColor.White.color) {
//                lastLine.isClip = true
//            }
//            canvas.lines.append(lastLine)                                   // 다시 선 배열에 추가
//        }
//        else {
//            guard var lastLine = canvas.lines.popLast() else { return }     // 선 배열에서 마지막 선을 pop
//            if (lineColor == EnumDrawingColor.White.color) {
//                lastLine.isClip = true
//            }
//            canvas.lines.append(lastLine)                                   // 다시 선 배열에 추가
//        }
//        canvas.setNeedsDisplay()                                        // 화면 상에 표시하기 위하여 호출(draw 함수가 호출됨)
//        undoButton.isEnabled = true
//    }
    
}
