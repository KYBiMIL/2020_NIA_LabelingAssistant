//
//  MainVC.swift
//  LabelingAssistant4ML
//
//  Created by Myeong-Joon Son on 2018. 10. 10..
//  Copyright © 2018년 uBiz Information Technology. All rights reserved.
//

import UIKit

//var ImageList:[ImageInfo] = []
var mainImageList:ImageList = ImageList()

var LabelList:LabelInfoList = LabelInfoList()

class LabelingVC: UIViewController, UIScrollViewDelegate {

    @IBOutlet var imageRegionView: UIView!
    var befErasingPoint:CGPoint?
    var befFreeCurvePoint:CGPoint?
    var imageArray:[ImageInfo] = [ImageInfo]()
    
    //var selectedMainImageCell:MainImageCell?
    var selectedMainImageCellIndexPath:IndexPath?
    //var selectedThumbnailCell:ThumbnailCell?
    var selectedThumbnailCellIndexPath:IndexPath?

    // ---------------------------------------------
    // 제스처 변수 선언
    // ---------------------------------------------
    var longPressGesture:UILongPressGestureRecognizer?       // 다각형에서 컨트롤포인트 삭제 또는 다각형 그리기 완료시 사용
    var tapGesture:UITapGestureRecognizer?                      // 타원을 그릴때와 종료할때 사용
    var doubleTapGesture:UITapGestureRecognizer?               // 참조 이미지 프로그램을 띄울때 사용
    var panGesture:UIPanGestureRecognizer?                      // 자유선, 닫힌자유선을 그리거나 지우개 모드에서 사용, 타원,다각형의 모양, 위치 변경을 위해서 사용
    var longPressGestureForNodelayPan:UILongPressGestureRecognizer?  // pan 제스처가 지연되는 현상이 발생하므로 대신에 짧은 long press로 대신함
    var tapGesture2:UITapGestureRecognizer?                     // 2 터치 탭, 이미지 원래 크기로 돌릴 때 사용
    // ---------------------------------------------

    var noticeClearMark = false
    
    var autoUpload = UploadThread()
    var canvas = Canvas()

    var lineType:LineType = LineType.FreeCurve
    var lineColor:UIColor = UIColor.red
    var lineWidth:CGFloat = 10.0
    var lineAlpha:CGFloat = 0.5

    var ellipseLayer = CAShapeLayer()
    var outlineLayer = CAShapeLayer()                       // mark의 frame에 매칭되는 shape layer
    var controlPoints: Array<CAShapeLayer> = Array()    // control point용 배열

    // ------------------------------------------------------------------------------
    // 마크 이동, 컨트롤포인트 조절 등 이전 위치 체크에 사용
    // ------------------------------------------------------------------------------
    var panPrevPoint = CGPoint(x:0,y:0)
    var isSelectedEllipse = false
    var isSelectedControlPoint = false
    var selectedControlPoint = CAShapeLayer()           // 선택된 control point
    var selectedControlPointPosition = -1               // 선택된 control point의 번호.타원의 경우 0..3, 다각형의 경우 0..n-1
    
    var freeOutlineLayer = CAShapeLayer()               
    var freeLayer = CAShapeLayer()
    var freeApex = [CGPoint]()
    
    var polygonLayer = CAShapeLayer()
    var polygonApex = [CGPoint]()
    
    var polygonStatus:PolygonStatus = .DrawStopped
    var isSelectedPolygon = false
    

    //----------------------------------------------------------------------------------------
    @IBOutlet var menuButton: UIBarButtonItem!
    // 히든용 뷰를 하나 만들어서 제스처에 사용
    let hiddenView = UIView()

    // 이미지 상단 정보
    @IBOutlet var signedUserNameLabel: UILabel!
    @IBOutlet var projectNameLabel: UILabel!
    @IBOutlet var labelingOrderLabel: UILabel!
    @IBOutlet var progress: UIProgressView!
    @IBOutlet var progressLabel: UILabel!
    @IBOutlet var imageIDLabel: UILabel!
    @IBOutlet weak var markCountLabel: UILabel!
    @IBOutlet weak var markCountTitle: UILabel!
    // 이미지 뷰 컨테이너 위에 오버레이하는 항목들
    @IBOutlet var isDropSwitch: UISwitch!
    @IBOutlet var dropSwitchView: UIView!
    
    @IBOutlet weak var dropInOutButton: UIButton!
    
    @IBOutlet var widthSliderView: DrawLineOnWidthSliderView!
    @IBOutlet weak var widthSlider: UISlider!
    
    
    @IBOutlet weak var alphaSliderView: UIView!
    @IBOutlet weak var alphaSlider: UISlider!
    @IBOutlet weak var settedAlphaLabel: UILabel!
    
    
    @IBOutlet weak var brightnessSlider: UISlider!
    @IBOutlet weak var contrastSlider: UISlider!
    @IBOutlet weak var saturationSlider: UISlider!
    
    
    @IBOutlet weak var isDropImage: UIImageView!
    // 이미지
    @IBOutlet var EditingImage : UIImageView!
    @IBOutlet var ScrollImage: UIScrollView!

    // 라벨 표시 테이블
    @IBOutlet var tableViewLabelLeft: UITableView!
    @IBOutlet var tableViewLabelRight: UITableView!
    
    @IBOutlet var collectionViewBottom: UICollectionView!
    

    // 화면 하단 버튼
    @IBOutlet var undoButton: UIButton!
    @IBOutlet var redoButton: UIButton!
    @IBOutlet var clearImageButton: UIButton!
    @IBOutlet var reloadButton: UIButton!
    @IBOutlet var drawCompleteButton: UIButton!
    

    @IBOutlet weak var fastSearchView: UIView!
    @IBOutlet weak var firstFastButton: UIButton!
    @IBOutlet weak var leftFastButton: UIButton!
    @IBOutlet weak var rightFastButton: UIButton!
    @IBOutlet weak var lastFastButton: UIButton!
    @IBOutlet var firstButton: UIButton!
    @IBOutlet var leftButton: UIButton!
    @IBOutlet var rightButton: UIButton!
    @IBOutlet var lastButton: UIButton!
    @IBOutlet var saveButton: UIButton!
    var isTotalExplore:Bool = true
    var fastSearch:Bool = false
    
    // 마크 타입/색상 선택 관련
    @IBOutlet var lineTypeSegmented: UISegmentedControl!
    @IBOutlet var lineColorSegmented: UISegmentedControl!
    @IBOutlet weak var cutModeSegmented: UISegmentedControl!
    var isCutMode:Bool = false
    
    @IBOutlet var labelLeftTitle: UILabel!
    @IBOutlet var labelRightTitle: UILabel!
    
    @IBOutlet var bottomEditMarkInfoView: UIView!
    //@IBOutlet var markSelectionButton: UIButton!
    
    // ------------------------------------------------------------------------------
    // 현재 이미지 인덱스 번호 선언
    // ------------------------------------------------------------------------------
    
    @IBOutlet weak var collectionViewMainImage: UICollectionView!
    var currentImageIndex = -1
    var image_last_row_num:Int = -1 // 서버로부터 가져온 메인 이미지 목록의 마지막 번호
    var image_count:Int = 0
    var mainImageNeedDownLoad = true
    

    // ------------------------------------------------------------------------------
    // 메인 이미지뷰에 보여줄 실제 이미지 파일을 서버로부터 가져와서 설정
    // ------------------------------------------------------------------------------
    var realImage:UIImage?
    var realImageWHRatio:Float?         // 실제이미지의 높이 대비 폭 비율
    var scrollImageWHRatio:Float?       // 스크롤 영역의 높이 대비 폭 비율
    var imageRealViewRatio:Float?       // 이미지뷰와 실제이미지의 비율(실제 이미지뷰 높이(폭) 대비 이미지뷰의 높이(폭)
    var existImage = false

    
    // ------------------------------------------------------------------------------
    // 이미지 라벨링 갯수 저장용
    // ------------------------------------------------------------------------------
    var total_count = 0     // 전체 이미지 갯수
    var complete_count = 0  // 완료 이미지 갯수
    var more_image = "N"    // 이미지가 더 있는지...

    // ------------------------------------------------------------------------------
    // 이미지 네비게이션 버튼 중 무엇이 선택되었는가
    // P:Prev, N:Next, L:Last, F:First, R:Random(랜덤은 서버 프로시저에서 차수가 1이 아닌 경우 체크하여 수행)
    // ------------------------------------------------------------------------------
    var FPNLFlag: String = "N"

    var errorMessage: String = "Error~"

    // ------------------------------------------------------------------------------
    // Marking 활성화 여부
    // ------------------------------------------------------------------------------
    var markEnabled = false
    
    // ------------------------------------------------------------------------------
    // 리뷰 모드시에 마크가 수정이 되었는지 여부, 수정이 되었으면 마크 이미지를 새로 업로드, 그렇지 않으면 안올림
    // ------------------------------------------------------------------------------
    var markUpdated = false
    var loadedMarkNum:Int = 0

    // ------------------------------------------------------------------------------
    // color
    // ------------------------------------------------------------------------------
    //let defaultCellBackgroundColor = UIColor.init(red: 232/255.0, green: 232/255.0, blue: 232/255.0, alpha: 1.0)
    let defaultCellBackgroundColor = UIColor.groupTableViewBackground
    let defaultCellTextColor = UIColor.black
    let selectedCellBackgroundColor = UIColor.orange
    let selectedCellTextColor = UIColor.white

    var labelsLeft = ["Negative", "Positive"]
    var labelsRight = ["Negative", "Positive"]
    
    var imageInfo:ImageInfo = ImageInfo()
    
    var selectedLabelLeftIndex = -1
    var selectedLabelRightIndex = -1
    var tableViewCellHeight = 10

    // ------------------------------------------------------------------------
    // 서버에 있는 소스 이미지를 다운로드 및 저장 : return : 이미지 저장 위치+파일명
    // ------------------------------------------------------------------------
    let sourceImageDirectoryName = "SourceImage"
    let markedImageDirectoryName = "MarkedImage"
    var sourceImageDirectoryURL:URL?
    var markedImageDirectoryURL:URL?
    //let markedImageNamePrefix = "M_"
    let markedImageNameSuffix = "_Mark"

    // ---------------------------------------------------------------------------------------
    // 레이아웃 관련 변수 정의
    // ---------------------------------------------------------------------------------------
    var constraints = [NSLayoutConstraint]()
    var collectionViewThumbnailWidthInPortraitMode:CGFloat = 90.0
    
    var tableViewLeftLeftConstant:CGFloat = 0
    var lineTypeSegmentedHeight:CGFloat = 35.0
    var lineTypeSegmentedWidth:CGFloat = 240.0
    var lineColorSegmentedWidth:CGFloat = 180.0
    var collectionThumbnailTopConstant:CGFloat = 75
    var lineTypeSegmenedTopConstant:CGFloat = 75

    
    // ---------------------------------------------------------------------------------------
    // Thumnail 관련
    // ---------------------------------------------------------------------------------------
    
    
    @IBOutlet weak var thumbnailGroupView: UIView!
    @IBOutlet weak var collectionViewThumbGroup: UICollectionView!
    var selectedGroupName:String = ""
    var selectedGroupIndex:Int = -1
    
    @IBOutlet weak var collectionViewThumbnail: UICollectionView!
    //var subImageList:[SubImageInfo] = [SubImageInfo]()
    var subImageList:SubImageList = SubImageList()
    var subImageArray:[SubImageInfo] = [SubImageInfo]()
    var last_row_num:Int = -1                                    // 섬네일컬렉션뷰
    var sub_image_count:Int = 0
    var selectedSubImageId:String = ""
    var selectedSubImageRowNum:Int = -1
    var sumImageNeedDownLoad = true

    // ------------------------- 메뉴 처리/Segue 처리  from ----------------------------------
    // menu 버튼 tab하면 메뉴 뷰 나오게 함
    let menuTransition = SlideMenuInTransition()
    var menuViewController:MenuVC = MenuVC()
    
    @IBAction func didTapMenu(_ sender: UIBarButtonItem) {
        menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuVC") as! MenuVC
        
        menuViewController.didTopMenuType = { menuType in
            p(menuType)
            self.transitionToNewContent(menuType)
        }
        menuViewController.modalPresentationStyle = .overCurrentContext
        menuViewController.transitioningDelegate = self // transitioningdeligate 설정
        present(menuViewController, animated: true)
        
        // 홈화면 위를 흐리게 하기 위해서 dimming view를 사용
        // dimming view를 탭하면 메뉴 뷰 사라지게 함
        setupDimmingViewTapGestureRecognizer(view: menuTransition.dimmingView)
        
    }
    

    // -----------------------------------------------------------------------------
    // 특정 화면에서 복귀할 때 다시 메뉴를 보여줄지를 담는 변수
    // -----------------------------------------------------------------------------
    var displayMenuView = false


    @IBAction func returnFromsegueAction(segue : UIStoryboardSegue) {
        returnFromOtherScreen(segue: segue)
    }

    // ------------------------- 메뉴 처리/Segue 처리 to ----------------------------------

    
    // 검토 설정 begin
    
    
    @objc func didTapReviewSetting(_ sender: UIButton) {

        performSegue(withIdentifier: "segueReviewSetting", sender: self)
    }
    

    func initLabelingSettingItem() {
        
        IsReviewMode = false
        IncludeLabelingDoneImage = true
//        fastSearchView.isHidden = false // 패스트 검색 버튼 보이게 .. 리뷰모드에서는 안보이게...  20200726
        
        isTotalExplore = IncludeLabelingDoneImage
        if (isTotalExplore) { setExploreButtonsOnOff(onOff: true) }
        
        LeftIndexOnReviewMode = -1
        RightIndexOnReviewMode = -1
        
        self.title = "라벨링 메인"
        
        _ = removeDir(fullPath: sourceImageDirectoryURL!.path)
        _ = removeDir(fullPath: markedImageDirectoryURL!.path)
    }
    
    func setLabelingSettingItem() {
        isTotalExplore = IncludeLabelingDoneImage
        if (isTotalExplore) { setExploreButtonsOnOff(onOff: true) }

        if (IsReviewMode) {
            self.title = "라벨링 메인 (리뷰 모드)"

            if (!naviBarBlinkRunning) {
                naviBarBlinkStart()
            }
        }
//        else if (IncludeLabelingDoneImage) {
//            self.title = "라벨링 메인 (전체 탐색 모드)"
//
//            naviBarBlinkStart()
//        }
        else {
            self.title = "라벨링 메인"

            self.navigationController?.navigationBar.barTintColor = UIColor.white
            if (naviBarBlinkRunning) {
                naviBarBlinkStop()
            }
        }
    }
    
    // 검토 설정 end
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        let ud = MyUserDefaults()
        ud.getUserDefaultAfterDidBecomeActive()
        
        // 이미지 디렉토리 URL 지정
        sourceImageDirectoryURL = DocumentsDirectoryURL.appendingPathComponent(sourceImageDirectoryName)
        markedImageDirectoryURL = DocumentsDirectoryURL.appendingPathComponent(markedImageDirectoryName)

        self.title = "라벨링 메인"
        let reloadItem = UIBarButtonItem(image: #imageLiteral(resourceName: "Reload-50"), style: .plain, target: self, action: #selector(reloadImageList(_:)))
        let loadSettingViewItem  = UIBarButtonItem(title: "리뷰모드설정", style: .plain, target: self, action: #selector(didTapReviewSetting(_:)))
        self.navigationItem.rightBarButtonItems = [reloadItem, loadSettingViewItem]

//        let textAttributes = [NSAttributedString.Key.foregroundColor:UIColor.red]
//        navigationController?.navigationBar.titleTextAttributes = textAttributes
        
        // 히든용 뷰를 하나 만들어서 제스처에 사용
        setHiddenView(view: hiddenView)
        checkHiddenView()
 
        setLineColorSegmented()
        
//        labelLeftTitle.underlineStyle()
//        labelRightTitle.underlineStyle()

        initObjectsInView()
        initTableViewProperty()
        initCollectionViewProperty()
        initImageViewProperty()

        initGesture()
        addGestureForMarking(lineType: .FreeCurve)
        
        initLabelingSettingItem()
        
        setupImageView()
        setupImageCollectionView()
        setupMainImageCollectionView()
        setupThumbGroupCollectionView()
        
//        lineTypeSegmented.frame = CGRect(origin: lineTypeSegmented.frame.origin, size: CGSize(width: lineTypeSegmented.frame.size.width, height: 35))

        setControlButtonPropertyUpperImage(button: clearImageButton)
        setControlButtonPropertyUpperImage(button: undoButton)
        setControlButtonPropertyUpperImage(button: redoButton)
        setControlButtonPropertyUpperImage(button: reloadButton)
        setDrawCompleteButtonProperty()
        
//        tableViewLabelLeft.translatesAutoresizingMaskIntoConstraints = false
//        tableViewLabelRight.translatesAutoresizingMaskIntoConstraints = false
//        collectionViewBottom.translatesAutoresizingMaskIntoConstraints = false
        
        // 자유형을 기본으로 설정
        lineTypeSegmented.selectedSegmentIndex = 0
        didTapLineTypeSegmented(lineTypeSegmented)
        
        resetSubImageList()

        // --------------------------------------------------------------------------
        // 이미지 상단 컨트롤 레이아웃 수동 지정을 위한 자동 레이아웃 설정 disable
        // --------------------------------------------------------------------------
        disableAutoresizingMask()
        
        widthSliderViewSetNeedsDisplay()
        
    }
    
    func widthSliderViewSetNeedsDisplay() {
        widthSliderView.lineColor = lineColor
        widthSliderView.lineWidth = lineWidth * ScrollImage.zoomScale
        widthSliderView.setNeedsDisplay()
    }
    
    // --------------------------------------------------------------------------
    // 이미지 상단 컨트롤 버튼 속성 설정
    // --------------------------------------------------------------------------
    func setControlButtonPropertyUpperImage(button:UIButton) {
        button.backgroundColor = .groupTableViewBackground
        button.layer.cornerRadius = 3.5
        button.layer.borderWidth = 1
        button.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        button.frame = CGRect(x: drawCompleteButton.frame.origin.x, y: lineTypeSegmented.frame.origin.y, width: drawCompleteButton.frame.width, height: lineTypeSegmented.frame.height)
    }
    
    // --------------------------------------------------------------------------
    // 이미지 상단 컨트롤 버튼 tint color 변경시 보더 컬러 색상 변경
    // --------------------------------------------------------------------------
    func setControlButtonBorderColorUpperImage() {
        drawCompleteButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        clearImageButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        undoButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        redoButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        reloadButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
    }
    
    // --------------------------------------------------------------------------
    // 이미지 상단 그리기 완료 버튼 속성 설정
    // --------------------------------------------------------------------------
    func setDrawCompleteButtonProperty() {
        drawCompleteButton.isHidden = true
        drawCompleteButton.backgroundColor = .groupTableViewBackground
        drawCompleteButton.layer.cornerRadius = 3.5
        drawCompleteButton.layer.borderWidth = 1
        drawCompleteButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        drawCompleteButton.frame = CGRect(x: drawCompleteButton.frame.origin.x, y: lineTypeSegmented.frame.origin.y, width: drawCompleteButton.frame.width, height: lineTypeSegmented.frame.height)
    }
    
    @objc func showLoginView() {
        performSegue(withIdentifier: "segueLogin", sender: nil)
    }
    
    @objc func showProjectSettingView() {
        if (!isLogin) {
            self.view.showToast(toastMessage: "로그인된 정보가 없습니다.", duration: 1.5)
            return
        }
        performSegue(withIdentifier: "segueProjectList", sender: nil)
    }
    
    // ---------------------------------------------------------------------
    // 하나하나 건너 뛸 것인지 라벨링을 하지 않은 이미지로 건너 뛸 것인지 결정하는 스위치
    // ---------------------------------------------------------------------
    @objc func explorerSwitchStateDidChange(_ sender:UISwitch){
        if (sender.isOn == true){
            p("UISwitch state is now ON")
            // 모든 이미지 네비게이션 버튼 활성화
            setExploreButtonsOnOff(onOff: true)
        }
        else{
            p("UISwitch state is now Off")
        }
    }

    // ---------------------------------------------------------------------
    // 이미지 목록 갱신
    // ---------------------------------------------------------------------
    @objc func reloadImageList(_ sender: UIButton) {

        if (!isWorking) { return }
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
        DoEvents(f: 0.05)
        
        clearLabelImage()
        loadData()

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
    }

    // ---------------------------------------------------------------------
    // viewWillAppear
    // ---------------------------------------------------------------------
    var beforeOrientation = OrientationValue
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        SetOrientation()
        
        if (displayMenuView) {
            if (isLogin && isWorking) {
            }
            else {
                didTapMenu(menuButton)
                displayMenuView = false
            }
        }

        checkHiddenView()
        
    }
    
    var lastSelectedIndex = -1
    // ---------------------------------------------------------------------
    // viewDidAppear
    // ---------------------------------------------------------------------
    override func viewDidAppear(_ animated: Bool) {

        super.viewDidAppear(animated)

        if (beforeOrientation != OrientationValue) {
            didTapDrawCompleteButton(self)
            reloadClick(self)
            //setupImageView()
            beforeOrientation = OrientationValue
        }

        // 이미지 파일 자동 업로드
        autoUpload.start()
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = self.view.frame
        self.view.addSubview(child.view)
        child.didMove(toParent: self)
        
        if (FirstDidBecomeActive) {
            checkLoginOutInfo(newLogin: isLogin)
            FirstDidBecomeActive = false
        }
        
        if (isFromLoginMenu) {
            p("---------------------------------------------------------- isFromLoginMenu")
            if (isNewLogined) {
                WorkingImageIndex = 0
                LabelList.arrayLabelInfo.removeAll()
                initLabelingSettingItem()
            }
            checkLoginOutInfo(newLogin: isNewLogined)
            isFromLoginMenu = false
        }
        else if (isFromProjectMenu) {
            p("---------------------------------------------------------- isFromProjectMenu")
            if (isNewProjectBegan) {
                WorkingImageIndex = 0
                LabelList.arrayLabelInfo.removeAll()
                initLabelingSettingItem()
            }
            checkWorkingProjectInfo(newProject: isNewProjectBegan)
            isFromProjectMenu = false
            
        }
        else if (isFromSettingMenu) {
            p("---------------------------------------------------------- isFromSettingMenu")
            if (IsSettingValueChanged) {
                // 세팅화면에서 돌아오면 탐색 버튼 true 20200606
                //LabelList.arrayLabelInfo.removeAll()
                
                setExploreButtonsOnOff(onOff: true)
                setLabelingSettingItem()
                
                resetObjectsRelatedToLabeling()
                
                if (IsReviewMode) {
                    //arrowLastClick(lastButton)

//                    fastSearchView.isHidden = true 20200726
//                    loadImageId("C")
                    
                    lastSelectedIndex = currentImageIndex       // 일반 탐색 모드 최종 조회 index 저장하여 돌아올때 사용
                    imageArray = mainImageList.doneImagesByResult(leftValue: LeftIndexOnReviewMode, rightValue: RightIndexOnReviewMode)
                    
                    currentImageIndex = imageArray.count - 1
                    self.collectionViewMainImage.reloadData()

                    if (currentImageIndex >= 0) {
                        let indexPath = IndexPath(item: currentImageIndex, section: 0)
                        
                        DispatchQueue.main.async {
                            self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
                        }
                        
                        loadedMarkNum = imageArray[currentImageIndex].markNum!
                        loadImageFromURL(index: currentImageIndex)    // 이미지를 가져옴
                        setLabelTouchEnable(enable: true)
                    }
                    else {
                        view.showToast(toastMessage: "해당하는 이미지가 없습니다.", duration: 1.5)
                        setLabelTouchEnable(enable: false)
                    }
                    
//                    collectionViewMainImage.reloadData()
                }
                else {
                    //arrowRightClick(rightButton)
//                    fastSearchView.isHidden = false 20200726
//                    loadImageId("C")

                    imageArray = mainImageList.images
                    
                    // 리뷰 모드에서 일반 모드로 돌아올때 최종 조회했던 index로 전환
                    p("imageArray.count, lastSelectedIndex, currentImageIndex: \(imageArray.count), \(lastSelectedIndex), \(currentImageIndex)")
                    currentImageIndex = (lastSelectedIndex < 0) ? currentImageIndex : lastSelectedIndex
                    self.collectionViewMainImage.reloadData()
                    
                    if (imageArray.count == 0) {
                        setLabelTouchEnable(enable: false)
                    }
                    else {
                        if (currentImageIndex < 0) {
                            currentImageIndex = 0
                        }
                        if (currentImageIndex < imageArray.count) {
                            let indexPath = IndexPath(item: currentImageIndex, section: 0)
                            
                            DispatchQueue.main.async {
                                self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
                            }
                            
                            loadedMarkNum = imageArray[currentImageIndex].markNum!
                            loadImageFromURL(index: currentImageIndex)    // 이미지를 가져옴
                        }
                        setLabelTouchEnable(enable: true)
                    }
                    
//                    collectionViewMainImage.reloadData()
                }
                setProgressValue()
                IsSettingValueChanged = false
            }
            isFromSettingMenu = false
        }

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()

        //adjustLabelListViewLocation()

//        let indexPath = IndexPath(item: 30, section: 0)
//
//        collectionViewMainImage.scrollToItem(at: indexPath, at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
//        //collectionViewMainImage.selectItem(at: indexPath, animated: false, scrollPosition: .centeredHorizontally)
//
//        let cell = collectionViewMainImage.cellForItem(at: indexPath) as! MainImageCell
//        cell.backgroundColor = UIColor.blue
//        cell.isSelected = true
//        //                //collectionViewMainImage.reloadData()
//        p("------------------------------------------------------------------------- cell.name : \(indexPath.item), \(cell.name.text!),\(cell.isSelected)")
//
//        //let cell = collectionViewMainImage.dequeueReusableCell(withReuseIdentifier: "IDMainImageCell", for: indexPath as IndexPath) as! MainImageCell
//        //
//
//        collectionViewMainImage.reloadData()
//

    }
    
    // ---------------------------------------------------------------------
    // viewWillDisappear
    // ---------------------------------------------------------------------
    override func viewWillDisappear(_ animated: Bool) {
        AppDelegate.AppUtility.lockOrientation(UIInterfaceOrientationMask.all)
    }
    
    
    // ---------------------------------------------------------------------
    // viewDidDisappear
    // ---------------------------------------------------------------------
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        autoUpload.stop()
    }
    
    // ---------------------------------------------------------------------
    // viewWillLayoutSubviews
    // ---------------------------------------------------------------------
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        adjustLabelListViewLocation()
        
    }
    
    // ---------------------------------------------------------------------
    // viewDidLayoutSubviews
    // ---------------------------------------------------------------------
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setControlButtonBorderColorUpperImage()

        tableViewLabelLeft.reloadData()
        //p("viewDidLayoutSubviews call tableViewLabelRight.reloadData() ")
        tableViewLabelRight.reloadData()
        collectionViewBottom.reloadData()
        collectionViewThumbGroup.reloadData()
        
    }

    func setHiddenView(view: UIView) {
        view.frame = self.view.frame
        view.backgroundColor = UIColor.white
        view.alpha = 0.35
        view.isHidden = true
        self.view.addSubview(view)
    }

    //---------------------------------------------------------------------------
    // line drawing color segmented control
    //---------------------------------------------------------------------------
    func setLineColorSegmented() {

//        lineColorSegmented.frame = CGRect(origin: lineColorSegmented.frame.origin, size: CGSize(width: lineColorSegmented.frame.size.width, height: 35))
        
        lineColorSegmented.removeAllSegments()
        for item in EnumDrawingColor.allCases {
            let title = EnumDrawingColor(rawValue: item.rawValue)?.title
            let color = EnumDrawingColor(rawValue: item.rawValue)?.displayColor
            let index = lineColorSegmented.numberOfSegments
            lineColorSegmented.insertSegment(withTitle: title, at: index, animated: false)
            (lineColorSegmented.subviews[index] as UIView).tintColor = color
        }
        lineColorSegmented.selectedSegmentIndex = 0
        
    }

    // --------------------------------------------------------------------------
    // 화면 상의 버튼 등 오브젝트 등의 속성 초기화
    // --------------------------------------------------------------------------
    func setProgressValue() {
        
        total_count = IsReviewMode ? mainImageList.doneImages().count : mainImageList.count
        complete_count = IsReviewMode ? imageArray.count : mainImageList.doneImages().count
        
        if (total_count == 0) {
            progress.progress = 0
            progressLabel.text = "0%(0/0)"
            return
        }

        // 이미지 랜덤 가져오는 부분에서 전체수와 완료를 가져와서 해당 변수에 저장한 것을 사용
        let value = Float(complete_count) / Float(total_count)
        progress.progress = value
        progressLabel.text = String(format: "%4.1f%%(%d%/%d)", value * 100, complete_count, total_count)
        if (complete_count == total_count) {
            progressLabel.textColor = UIColor.red
        }
        else {
            progressLabel.textColor = UIColor.black
        }

    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if UIDevice.current.orientation.isLandscape {
            p("isLandscape")
        }
        else {
            p("portrait")
        }
    }
    
    func initObjectsInView() {
        
        // 하단 네비게이션 툴바 히든 처리
        self.navigationController?.toolbar.isHidden = true
        
        // 진행률 오브젝트
//        progress.transform = progress.transform.scaledBy(x: 1.0, y: 5.0)
        progress.transform = CGAffineTransform(scaleX: 1, y: 5)
        progress.clipsToBounds = true
        setProgressValue()

        // mark reset/undo/redo
        clearImageButton.isEnabled = true
        undoButton.isEnabled = true
        redoButton.isEnabled = true

        saveButton.isEnabled = false

        // 하단 버튼 모양 변경(둥글게)
        //buttonRadius(clearImageButton)
        //buttonRadius(undoButton)
        //buttonRadius(redoButton)
        //buttonRadius(reloadButton)
        
//        buttonRadius(leftFastButton) 20200726
//        buttonRadius(rightFastButton)
//        buttonRadius(firstFastButton)
//        buttonRadius(lastFastButton)
//        buttonRadius(firstButton)
//        buttonRadius(leftButton)
//        buttonRadius(rightButton)
//        buttonRadius(lastButton)
        buttonRadius(saveButton)
        
        // undo redo 활성화 여부
        undoredoEnable()
    }
    
    // --------------------------------------------------------------------------
    // 버튼 코너 둥글게
    // --------------------------------------------------------------------------
    func buttonRadius(_ button: UIButton) {
        button.layer.backgroundColor = UIColor.init(red: 232/255.0, green: 232/255.0, blue: 232/255.0, alpha: 1.0).cgColor
        button.layer.cornerRadius = 10;
        button.clipsToBounds = true;
    }
    
    // --------------------------------------------------------------------------
    // 라벨링 작업과 관련된 오브젝트 리셋(이미지가 변경될 때)
    // --------------------------------------------------------------------------
    func resetObjectsRelatedToLabeling() {
        // 라벨 관련
        selectedLabelLeftIndex = -1
        selectedLabelRightIndex = -1
        tableViewLabelLeft.reloadData()
        //p("resetObjectsRelatedToLabeling call tableViewLabelRight.reloadData() ")
        tableViewLabelRight.reloadData()
        collectionViewBottom.reloadData()
        
        // 버튼 관련
        saveButton.isEnabled = false
    }
    
    // --------------------------------------------------------------------------
    // 라벨 목록을 보여주는 좌.우 테이블뷰의 속성 초기화
    // --------------------------------------------------------------------------
    func initTableViewProperty() {
        // tableView delegate, datasource 설정
        tableViewLabelLeft.delegate = self
        tableViewLabelLeft.dataSource = self
        tableViewLabelLeft.tag = 0

        // tableView 2개를 사용하기 위하여 등록해야 함
        tableViewLabelLeft.register(UITableViewCell.self, forCellReuseIdentifier: "LabelCellLeft")
        
        tableViewLabelRight.delegate = self
        tableViewLabelRight.dataSource = self
        tableViewLabelRight.tag = 1

        // tableView 2개를 사용하기 위하여 등록해야 함
        tableViewLabelRight.register(UITableViewCell.self, forCellReuseIdentifier: "LabelCellRight")
    }
    
    func initCollectionViewProperty() {
        // collectionView delegate, datasource 설정
        collectionViewBottom.delegate = self
        collectionViewBottom.dataSource = self
        collectionViewBottom.tag = 0
    }

    // --------------------------------------------------------------------------
    // 메인 이미지뷰 속성 설정 및 초기 이미지 설정
    // --------------------------------------------------------------------------
    func initImageViewProperty() {
        EditingImage.isUserInteractionEnabled = true
        noticeClearMark = false
        EditingImage.clipsToBounds = true
        EditingImage.backgroundColor = UIColor.darkGray

        // 초기 이미지 설정
        EditingImage.image = #imageLiteral(resourceName: "건양대학교병원 야경")
        EditingImage.contentMode = .scaleToFill
        
        originalImage = EditingImage.image
        resetImageFilter()
    }
    
    // ------------------------------------------------------------------------------
    // 로그인/아웃시 이벤트 받아서 처리하는 함수
    // ------------------------------------------------------------------------------
    @objc func whenLoginOut() {
        if (isLogin) {
            signedUserNameLabel.text = LoginName
        }
        else {
            signedUserNameLabel.text = "not logged in"
        }
        clearLabelImage()
        
        // 프로그램 실행 후 UserDefault 값을 읽은 최종 상태가 로그인 상태가 아니면 로그인 창을 띄워 준다.
        // FirstDidBecomeActive 값은 AppDelegate에서 변경한다.
        if (FirstDidBecomeActive && !isLogin) {
            performSegue(withIdentifier: "segueLoginOut", sender: self)
        }
    }
    
    // ------------------------------------------------------------------------------
    // 프로젝트 및 차수 선택 후 라벨링 시작 및 종료시 이벤트 받아서 처리하는 함수
    // ------------------------------------------------------------------------------
    @objc func whenLabelingBeginEnd() {
        clearLabelImage()
        if (isWorking) {
            loadData()
        }
        
        // 프로그램 실행 후 UserDefault 값을 읽은 최종 상태가 로그인 상태이고 라벨링 중인 프로젝트가 없으면 프로젝트 목록 창을 띄워 준다.
        // FirstDidBecomeActive 값은 AppDelegate에서 변경한다.
        if (FirstDidBecomeActive && isLogin && !isWorking) {
            transitionToNewContent(MenuType.projectList)
        }
        
    }
    

    // ------------------------------------------------------------------------------
    // 로그인/아웃시 체크(최초 로딩시에도 수행)
    // ------------------------------------------------------------------------------
    @objc func checkLoginOutInfo(newLogin new_login:Bool) {
        
        if (new_login) {
            signedUserNameLabel.text = LoginName
            clearLabelImage()
            // 라벨링 중인 작업이 있으면 Loading
            if (isWorking) {
                loadData()
            }
            // 라벨링 작업중인 것이 없으면 프로젝트 목록 화면으로 이동
            else {
                DispatchQueue.main.async() {
                    self.performSegue(withIdentifier: "segueProjectList", sender: nil)
                }
            }
        }
        else {
            if (!isLogin) {
                signedUserNameLabel.text = "not logged in"
                clearLabelImage()
                // 맨처음 로딩 했을 경우에만 체크하여 로그인 페이지로 이동
                if (FirstDidBecomeActive) {
                    DispatchQueue.main.async() {
                        self.performSegue(withIdentifier: "segueLoginOut", sender: nil)
                    }
                }
            }
        }
        
    }
    
    // ------------------------------------------------------------------------------
    // 프로젝트 및 차수 선택 후 라벨링 시작 및 종료시 체크
    // ------------------------------------------------------------------------------
    @objc func checkWorkingProjectInfo(newProject new_project:Bool) {
        if (new_project) {
            clearLabelImage()
            if (isWorking) {
                loadData()
            }
        }
        else {
            if (!isWorking) {
                clearLabelImage()
            }
        }
    }
    
    func clearLabelImage() {
        // project Info
        projectNameLabel.text = "________________________"
        labelingOrderLabel.text = "__"

        // 전역 변수 목록
        mainImageList.removeAll()

        imageIDLabel.text = " "
        setProgressValue()

        // 내부 변수
        canvas.clear()
        markCountLabel.text = "\(canvas.lines.count)개"

        undoredoEnable()
        resetObjectsRelatedToLabeling()
        
    }
    

    
    func showNotRegisterdMessage() {
        if (currentImageIndex < 0 || currentImageIndex > imageArray.count) {
            p("Array Index Error : showNotRegisterdMessage() number \(currentImageIndex)")
            return
        }
        guard let imageId = imageArray[currentImageIndex].id else { return }
        self.view.showToast(toastMessage: "\n" + imageId + "\n\n서버에 이미지가 등록되지 않았습니다.\n", duration: 1.5)
    }

    // ------------------------------------------------------------------------------
    // 이미지 파일 url 변수 정의
    // ------------------------------------------------------------------------------
    var savedMarkedImageUrlPath:String?
    var savedSourceImageUrlPath:String?
    

    var isExistSelectedMark = false                     // 선택된 mark가 있는지

    var isExistSelectedControlPoint = false             // 선택된 control point가 있는지

    var lastScale:CGFloat!
    
    func disableAnimation(_ closure:()->Void){
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        closure()
        CATransaction.commit()
    }
    
    // IBAction Process
    @IBAction func undoMark(_ sender: Any) {
        canvas.undo()
        markCountLabel.text = "\(canvas.lines.count)개"
        undoredoEnable()
    }

    @IBAction func RedoMark(_ sender: Any) {
        canvas.redo()
        markCountLabel.text = "\(canvas.lines.count)개"
        undoredoEnable()
    }
    
    func checkHiddenView() {
        if (mainImageList.count == 0) {
            hiddenView.isHidden = false
        }
        else {
            hiddenView.isHidden = true
        }
    }
    
    @IBAction func widthSliderChanged(_ sender: Any) {
        let currentValue:Float = widthSlider.value * 20
        let roundedValue = roundf(currentValue * 10) / 10
        lineWidth = CGFloat(roundedValue)

        widthSliderViewSetNeedsDisplay()
    }
    
    @IBAction func alphaSliderChanged(_ sender: UISlider) {
        let currentValue:Float = alphaSlider.value
        let roundedValue = roundf(currentValue * 10) / 10
        settedAlphaLabel.text = "\(roundedValue)"
        lineAlpha = CGFloat(roundedValue)
        
        for index in 0 ..< canvas.lines.count {
            canvas.lines[index].alpha = lineAlpha
        }

        canvas.setNeedsDisplay()
    }
    
    
    // ----------------------------------------------------------------------
    // Image filter
    // ----------------------------------------------------------------------
    var filter:CIFilter! = CIFilter()
    var context = CIContext()
    var filteredImage:CIImage? = CIImage()
    var sliderValue:Float?
    var originalImage:UIImage?
    
    // ----------------------------------------------------------------------
    // brightness 수집
    // ----------------------------------------------------------------------
    @IBAction func brightnessSliderChanged(_ sender: UISlider) {
        let roundedValue = roundf(sender.value * 100) / 100
        sender.value = roundedValue
        setImageFilter()
        sliderValue = sender.value
    }
    
    @IBAction func brightnessSliderTouchUp(_ sender: UISlider) {
        sender.value = sliderValue!
        print("brightnessSliderTouchUp : \(sender.value)")
    }
    
    // ----------------------------------------------------------------------
    // contrast 수집
    // ----------------------------------------------------------------------
    @IBAction func contrastSliderChanged(_ sender: UISlider) {
        let roundedValue = roundf(sender.value * 10) / 10
        sender.value = roundedValue
        setImageFilter()
        sliderValue = sender.value
    }
    
    @IBAction func contrastSliderTouchUp(_ sender: UISlider) {
        sender.value = sliderValue!
        print("contrastSliderTouchUp : \(sender.value)")
    }

    // ----------------------------------------------------------------------
    // saturation 수집
    // ----------------------------------------------------------------------
    @IBAction func saturationSliderChanged(_ sender: UISlider) {
        let roundedValue = roundf(sender.value * 10) / 10
        sender.value = roundedValue
        setImageFilter()
        sliderValue = sender.value
    }
    
    
    @IBAction func saturationSliderTouchUp(_ sender: UISlider) {
        sender.value = sliderValue!
        print("saturationSliderTouchUp : \(sender.value)")
    }

    // ----------------------------------------------------------------------
    // 이미지 필터 초기화
    // ----------------------------------------------------------------------
    @IBAction func removeFilterButtonClicked(_ sender: UIButton) {
        EditingImage.image = originalImage
        resetImageFilter()
    }

    func resetImageFilter() {
        brightnessSlider.value = 0.0
        contrastSlider.value = 1.0
        saturationSlider.value = 1.0
    }

    // ----------------------------------------------------------------------
    // 이미지에 설정된 필터 한꺼번에 세팅. 따로따로 하면 안됨
    // ----------------------------------------------------------------------
    func setImageFilter() {
        EditingImage.image = originalImage
        let beginImage = CIImage(image: EditingImage.image!)
        self.filter = CIFilter(name: "CIColorControls")!
        self.filter?.setValue(beginImage, forKey: kCIInputImageKey)
        self.filter.setValue(brightnessSlider.value, forKey: kCIInputBrightnessKey)
        self.filter.setValue(contrastSlider.value, forKey: kCIInputContrastKey)
        self.filter.setValue(saturationSlider.value, forKey: kCIInputSaturationKey)
        self.filteredImage = self.filter?.outputImage
        EditingImage.image = UIImage(cgImage: self.context.createCGImage(self.filteredImage!, from: (self.filteredImage?.extent)!)!)
    }
    // ----------------------------------------------------------------------

    
    // ----------------------------------------------------------------------
    // 이미지 drop 및 해제
    // ----------------------------------------------------------------------
    @IBAction func dropInOutButtonClicked(_ sender: Any) {
        p("dropInOutButtonClicked")
        isDropSwitch.isOn = !isDropSwitch.isOn
        dropSwitchTriggered(isDropSwitch)
    }
    
    @IBAction func dropSwitchTriggered(_ sender: UISwitch) {
        var questionMessage = "DROP 하시겠습니까?"
        if (!sender.isOn) {
            questionMessage = "DROP 해제 하시겠습니까?"
        }

        let dialogMessage = UIAlertController(title: "확인", message: questionMessage, preferredStyle: .alert)
        let ok = UIAlertAction(title: "예", style: .destructive, handler: { (action) -> Void in
            // ------------------------------------------------
            // 스피너 시작
            // ------------------------------------------------
            let child = SpinnerViewController()
            child.view.frame = self.view.frame
            self.view.addSubview(child.view)
            child.didMove(toParent: self)
            
            if (self.saveDropResult()) {


                p("Drop/Cancel Process OK")
                if (sender.isOn) {
                    self.view.showToast(toastMessage: "Drop 처리되었습니다.", duration: 1.0)
                }
                else {
                    self.view.showToast(toastMessage: "Drop 해제되었습니다.", duration: 1.0)
                }
                
                // 마지막에 저장했던 이미지를 유저디폴트에 저장
                let imageId = self.imageArray[self.currentImageIndex].id!
                UserDefaults.standard.set(imageId, forKey: DefaultKey_LastLabelingImageId)
                LastLabelingImageId = imageId
                
                self.setLabelingResultInfoByDrop(isDrop:sender.isOn)

                if (sender.isOn) {
                    self.arrowRightClick()
                }
                else {
                }

                self.setLabelTouchEnable(enable: !sender.isOn)
                self.setProgressValue()
            }
            else {
                p("Drop/Cancel Process Error")
                sender.setOn(!sender.isOn, animated: false)
                
                if (LastURLErrorMessage != "") {
                    let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
                    let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
                        //self.dismiss(animated: true, completion: nil)
                        alertProgressNoAction.dismiss(animated: true, completion: nil)
                    })
                    alertProgressNoAction.addAction(otherAction)
                    self.present(alertProgressNoAction, animated: false, completion: nil)
                }
            }
            // ------------------------------------------------
            // 스피너 종료
            // ------------------------------------------------
            child.willMove(toParent: nil)
            child.view.removeFromSuperview()
            child.removeFromParent()
            self.dropInOutButton.setImage(self.isDropSwitch.isOn ? #imageLiteral(resourceName: "Trash-Out") : #imageLiteral(resourceName: "Trash-In"), for: .normal)
        })
        let cancel = UIAlertAction(title: "아니오", style: .cancel) { (action) -> Void in
            sender.setOn(!sender.isOn, animated: false)
            self.dropInOutButton.setImage(self.isDropSwitch.isOn ? #imageLiteral(resourceName: "Trash-Out") : #imageLiteral(resourceName: "Trash-In"), for: .normal)
        }
        dialogMessage.addAction(ok)
        dialogMessage.addAction(cancel)
        self.present(dialogMessage, animated: true, completion: nil)
    }
    

    // ----------------------------------------------------------------------
    // 라벨링 결과와 마킹 결과 저장 버튼 클릭시
    // ----------------------------------------------------------------------
    @IBAction func didTapSaveButton(_ sender: Any) {
        
        if isDropSwitch.isOn {
            self.view.showToast(toastMessage: "Drop 해제 후 라벨링이 가능합니다.", duration: 1.0)
            return
        }
        
        didTapDrawCompleteButton(self)
        
        // save하기 전에 원래대로 필터가 없는 원본이미지를 매핑
        EditingImage.image = originalImage
        resetImageFilter()
        
        if (!existImage) {
            showNotRegisterdMessage()
            return
        }
        
        saveLabelingResultAndMark()
        
    }
    
    
    // -----------------------------------------------------------------------------
    // 저장버튼 활성화 여부 결정
    // -----------------------------------------------------------------------------
    func checkSaveButtonShow() {
        
        // 등록된 이미지가 없는 경우
        if (!existImage) {
            saveButton.isEnabled = false;
            return;
        }
        
        // 좌측 라벨 목록이 존재하면...
        if (LabelList.getLabelCount(location: 0) > 0) {
            // 좌,우측 라벨 목록이 모두 존재하면...
            if (LabelList.getLabelCount(location: 1) > 0) {
                saveButton.isEnabled = (selectedLabelLeftIndex < 0 || selectedLabelRightIndex < 0) ? false : true;
            }
                // 좌측 라벨 목록만 존재하면...
            else {
                saveButton.isEnabled = selectedLabelLeftIndex < 0 ? false : true;
            }
        }
        else {
            // 우측 라벨 목록만 존재하면...
            if (LabelList.getLabelCount(location: 1) > 0) {
                saveButton.isEnabled = selectedLabelRightIndex < 0 ? false : true;
            }
                // 좌,우측 라벨 목록이 모두 없으면...
            else {
                saveButton.isEnabled = false;
            }
        }
    }
    
    var beforeleftButtonisEnabled = true;
    var beforerightButtonisEnabled = true;
    var beforefirstButtonisEnabled = true;
    var beforelastButtonisEnabled = true;
    var beforeImageID = ""

    func setExploreButtonsOnOff(onOff:Bool) {
//        leftButton.isEnabled = onOff  20200726
//        rightButton.isEnabled = onOff
//        firstButton.isEnabled = onOff
//        lastButton.isEnabled = onOff
    }
    
    func setExploreButtons(enable:Bool) {
        
//        if (fastSearch) { 20200726
//            leftButton.isEnabled = true
//            rightButton.isEnabled = true
//            firstButton.isEnabled = true
//            lastButton.isEnabled = true
//            return
//        }
//
//        // 일단 무조건 위처럼 true로 하자.. 막 꼬였다.
//
//        if (enable) {
//            leftButton.isEnabled = beforeleftButtonisEnabled
//            rightButton.isEnabled = beforerightButtonisEnabled
//            firstButton.isEnabled = beforefirstButtonisEnabled
//            lastButton.isEnabled = beforelastButtonisEnabled
//        }
//        else {
//            beforeleftButtonisEnabled = leftButton.isEnabled
//            beforerightButtonisEnabled = rightButton.isEnabled
//            beforefirstButtonisEnabled = firstButton.isEnabled
//            beforelastButtonisEnabled = lastButton.isEnabled
//
//            if (currentImageIndex >= 0) {
//                if (mainImageList.count > 0) {
//                    if let befId = mainImageList.images[currentImageIndex].id {
//                        beforeImageID = befId
//                    }
//                    else {
//                        beforeImageID = ""
//                    }
//                }
//                else {
//                    beforeImageID = ""
//                }
//            }
//            else {
//                beforeImageID = ""
//            }
//
//            leftButton.isEnabled = enable
//            rightButton.isEnabled = enable
//            firstButton.isEnabled = enable
//            lastButton.isEnabled = enable
//
//        }
//
//        if (enable && more_image != "ERROR") {
//        //if (enable) {
//
//            switch FPNLFlag {
//            case "F", "P":
//                if (more_image == "N" || ResponseErrorCode == -90005) {
//                    leftButton.isEnabled = false
//                    firstButton.isEnabled = false
//                }
//                if (currentImageIndex >= 0) {
//                    if (beforeImageID != mainImageList.images[currentImageIndex].id!) {
//                        rightButton.isEnabled = true
//                        lastButton.isEnabled = true
//                    }
//                }
//            case "N", "L":
//                if (more_image == "N" || ResponseErrorCode == -90005) {
//                    rightButton.isEnabled = false
//                    lastButton.isEnabled = false
//                }
//                if (currentImageIndex >= 0) {
//                    if (beforeImageID != mainImageList.images[currentImageIndex].id!) {
//                        leftButton.isEnabled = true
//                        firstButton.isEnabled = true
//                    }
//                }
//            case "C":
//                rightButton.isEnabled = true
//                lastButton.isEnabled = true
//                rightButton.isEnabled = true
//                lastButton.isEnabled = true
//            default :
//                rightButton.isEnabled = true
//                lastButton.isEnabled = true
//                rightButton.isEnabled = true
//                lastButton.isEnabled = true
//                break;
//            }
//        }
    }
    

    // -----------------------------------------------------------------
    // 마크 모양 세그멘티드뷰 선택시
    // -----------------------------------------------------------------
    @IBAction func didTapLineTypeSegmented(_ sender: Any) {
        
        // 이전 상황이 타원 및 다각형인 경우에는 강제로 완료버튼을 tap
        if (lineType == .Ellipse || lineType == .Polygon) {
            didTapDrawCompleteButton(self)
        }
        
        switch lineTypeSegmented.selectedSegmentIndex {
        case 0:
            lineType = LineType.FreeCurve
            drawCompleteButton.isHidden = true
            widthSliderView.isHidden = false
        case 1:
            lineType = LineType.ClosedCurve
            drawCompleteButton.isHidden = true
            widthSliderView.isHidden = true
        case 2:
            lineType = LineType.Ellipse
            drawCompleteButton.isHidden = false
            widthSliderView.isHidden = true
        case 3:
            lineType = LineType.Polygon
            drawCompleteButton.isHidden = false
            widthSliderView.isHidden = true
        case 4:
            lineType = LineType.Eraser
            drawCompleteButton.isHidden = true
            widthSliderView.isHidden = true
        default:
            lineType = LineType.FreeCurve
            drawCompleteButton.isHidden = true
            widthSliderView.isHidden = true
        }
        if (!drawCompleteButton.isHidden) {
            drawCompleteButton.layer.borderColor = lineTypeSegmented.tintColor.cgColor
        }
        
        // 마킹용 제스처 설정 호출
        addGestureForMarking(lineType: lineType)
    }

    // -----------------------------------------------------------------
    // 다각형 마크의 경우 long press로 완료 처리하는 것과 동일한 버튼 클릭
    // -----------------------------------------------------------------
    @IBAction func didTapDrawCompleteButton(_ sender: Any) {
        switch lineType {
        case LineType.FreeCurve,
             LineType.Eraser,
             LineType.ClosedCurve:
            break
        case LineType.Ellipse:
            if (canvas.isDrawing) {
                drawEllipseEnded()
            }
            break
        case LineType.Polygon:
            if (polygonStatus == .Moving || polygonStatus == .DrawStarted) {
                polygonStatus = .DrawStopping
                drawEnded_Polygon()
            }
            break
        }
    }
    
    // -----------------------------------------------------------------
    // 마크 색상 세그멘티드뷰 선택시
    // -----------------------------------------------------------------
    @IBAction func didTapLineColorSegmented(_ sender: Any) {
        lineColor = EnumDrawingColor(rawValue: lineColorSegmented.selectedSegmentIndex)!.color
        if (lineType == .Ellipse) {
            ellipseLayer.strokeColor = lineColor.cgColor
        }
        else {
            polygonLayer.strokeColor = lineColor.cgColor
        }
        widthSliderViewSetNeedsDisplay()
    }
    
    // -----------------------------------------------------------------
    // 그리고 모드/자르기 모드 선택시
    // -----------------------------------------------------------------
    @IBAction func didTapCutModeSegmented(_ sender: Any) {
        if (cutModeSegmented.selectedSegmentIndex == 0) {
            isCutMode = false
        }
        else {
            isCutMode = true
        }
    }
    
    
    @IBAction func didTapClearImage(_ sender: Any) {
        if let sourceImage = UIImage(contentsOfFile: savedSourceImageUrlPath!) {
            EditingImage.image = sourceImage
            originalImage = sourceImage
            resetImageFilter()
        }
        ScrollImage.zoomScale = 1.0
        canvas.clear(exceptUndo:true)
        markCountLabel.text = "\(canvas.lines.count)개"

        undoredoEnable()
        EditingImage.isUserInteractionEnabled = true
        noticeClearMark = false
        
        // 마킹을 다시 하기 위하여 클리어되었으므로, 업로드 대상
        markUpdated = true
        
    }

    @IBAction func arrowFirstFastClick(_ sender: Any) {
//        fastSearch = true 20200726
//        loadImageId("F")
    }
    
    @IBAction func arrowLeftFastClick(_ sender: Any) {
//        fastSearch = true
//        loadImageId("P")
    }
    
    @IBAction func arrowRightFastClick(_ sender: Any) {
//        fastSearch = true
//        loadImageId("N")
    }
    
    @IBAction func arrowLastFastClick(_ sender: Any) {
//        fastSearch = true
//        loadImageId("L")
    }
    
    @IBAction func arrowFirstClick(_ sender: Any) {
//        fastSearch = false
//        loadImageId("F")
//        if (WorkingLabelingOrder == 1) {
//            leftButton.isEnabled = false
//            firstButton.isEnabled = false
//        }
    }
    
    
    @IBAction func arrowLeftClick(_ sender: Any) {
//        fastSearch = false
//        loadImageId("P")
//        if (WorkingLabelingOrder == 1 && ResponseErrorCode == -90005) {
//            leftButton.isEnabled = false
//            firstButton.isEnabled = false
//        }
    }

    @IBAction func arrowRightClick(_ sender: Any? = nil) {
//        fastSearch = false
//        loadImageId("N")
//        if (WorkingLabelingOrder == 1 && ResponseErrorCode == -90005) {
//            rightButton.isEnabled = false
//            lastButton.isEnabled = false
//        }

//        let array = IsReviewMode ? mainImageList.doneImages() : mainImageList.images
        let num = currentImageIndex + 1
        
//        p("array, num : \(imageArray.count), \(num)")
        if (num > imageArray.count - 1) {
            return
        }

        if let befIndexPath = selectedMainImageCellIndexPath {
            if let befCell = collectionViewMainImage.cellForItem(at: befIndexPath) as? MainImageCell {
                if (imageArray[currentImageIndex].markNum! > 0) {
                    befCell.colorType(.marked)
                }
                else if (imageArray[currentImageIndex].isLabelingDone!) {
                    befCell.colorType(.marked)
                }
                else if (imageArray[currentImageIndex].isDrop! == "Y") {
                    befCell.colorType(.drop)
                }
                else {
                    befCell.colorType(.basic)
                }
            }
        }

//        if let befCell = selectedMainImageCell {
//            if (imageArray[currentImageIndex].markNum! > 0) {
//                befCell.colorType(.marked)
//            }
//            else if (imageArray[currentImageIndex].isLabelingDone!) {
//                befCell.colorType(.marked)
//            }
//            else if (imageArray[currentImageIndex].isDrop! == "Y") {
//                befCell.colorType(.drop)
//            }
//            else {
//                befCell.colorType(.basic)
//            }
//        }
        
        currentImageIndex = num
        
        let indexPath = IndexPath(item: currentImageIndex, section: 0)

        DispatchQueue.main.async {
            let cell = self.collectionViewMainImage.cellForItem(at: indexPath) as! MainImageCell
            cell.colorType(.selected)
            self.selectedMainImageCellIndexPath = indexPath

            self.collectionViewMainImage.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
            //self.collectionViewMainImage.reloadData()
        }
        

        loadedMarkNum = imageArray[currentImageIndex].markNum!
        loadImageFromURL(index: currentImageIndex)    // 이미지를 가져옴

    }

    @IBAction func arrowLastClick(_ sender: Any) {
//        fastSearch = false
//        loadImageId("L")
//        if (WorkingLabelingOrder == 1) {
//            rightButton.isEnabled = false
//            lastButton.isEnabled = false
//        }
    }

//    func getFirstImageIndex(_ isTotalExplore:Bool,_ currIndex:Int) -> Int { 20200726
//        // 배열에 값이 없거나 첫번째 위치이면 현재값 리턴
//        if (mainImageList.count == 0 || currentImageIndex == 0) { return currIndex }
//
//        // 첫번째 인덱스로 가려면..
//        if (isTotalExplore) {
//            return 0;
//        }
//        // 작업하지 않은 첫번째 이미지로 가려면..
//        else {
//            // 인덱스 값을 0부터 변경하면서 찾음
//            for i in (0 ..< mainImageList.count) {
//                if let done = mainImageList.images[i].isLabelingDone {
//                    // 아직 라벨링 작업을 하지 않았으면 리턴
//                    p("인덱스 값 : ", i, ", ", done);
//                    if (!done) {
//                        return i;
//                    }
//                }
//            }
//            return currIndex;
//        }
//    }
//
//    func getPreviousImageIndex(_ isTotalExplore:Bool,_ currIndex:Int) -> Int {
//        // 배열에 값이 없거나 첫번째 위치이면 현재값 리턴
//        if (mainImageList.count == 0 || currentImageIndex == 0) { return currIndex }
//
//        // 이전 인덱스로 가려면..
//        if (isTotalExplore) {
//            return currIndex - 1;
//        }
//        // 작업하지 않은 첫번째 이전 이미지로 가려면..
//        else {
//            // 인덱스 값을 뒤에서부터 변경하면서 찾음
//            for i in (0 ..< currIndex).reversed() {
//                if let done = mainImageList.images[i].isLabelingDone {
//                    // 아직 라벨링 작업을 하지 않았으면 리턴
//                    p("인덱스 값 : ", i, ", ", done);
//                    if (!done) {
//                        return i;
//                    }
//                }
//            }
//            return currIndex;
//        }
//    }
    
    @IBAction func reloadClick(_ sender: Any) {
        if (imageArray.count == 0) { return }
        
        if (WorkingProjectMulti == "Y") {
            if (selectedSubImageRowNum >= 0 && selectedSubImageRowNum < subImageArray.count) {
                loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
                resetWhenImageChanged()
            }
        }
        else {
            loadImageFromURL(index: currentImageIndex)
        }
        
//        if let sourceImage = UIImage(contentsOfFile: savedMarkedImageUrlPath!) {
//            EditingImage.image = sourceImage
//            originalImage = sourceImage
//            resetImageFilter()
//        }
//        ScrollImage.zoomScale = 1.0
//        canvas.clear(exceptUndo:true)
//        markCountLabel.text = "\(canvas.lines.count)개"
//
//        undoredoEnable()
//        EditingImage.isUserInteractionEnabled = true
//        noticeClearMark = false
//
//        // 마킹을 다시 하기 위하여 클리어되었으므로, 업로드 대상
//        markUpdated = true
//
//
//
        
    }


//    func getNextImageIndex(_ isTotalExplore:Bool,_ currIndex:Int) -> Int { 20200726
//        // 배열에 값이 없거나 마지막 위치이면 현재 값 리턴
//        if (mainImageList.count == 0 || (currIndex + 1) >= mainImageList.count) { return currIndex }
//
//        p("현재 인덱스 값 : ", currIndex);
//        // 다음 인덱스로 가려면..
//        if (isTotalExplore) {
//            return currIndex + 1;
//        }
//        else {
//            // 작업하지 않은 이미지로 가려면..
//            for i in (currIndex+1) ..< mainImageList.count {
//                if let done = mainImageList.images[i].isLabelingDone {
//                    // 아직 라벨링 작업을 하지 않았으면 리턴
//                    p("인덱스 값 : ", i, ", ", done);
//                    if (!done) {
//                        return i;
//                    }
//                }
//                else {
//                    return i;
//                }
//            }
//            return currIndex;
//        }
//    }
//
//    func getLastImageIndex(_ isTotalExplore:Bool,_ currIndex:Int) -> Int {
//        // 배열에 값이 없거나 마지막 위치이면 현재 값 리턴
//        if (mainImageList.count == 0 || currentImageIndex == (mainImageList.count - 1)) { return currIndex }
//
//        p("현재 인덱스 값 : ", currIndex);
//        // 마지막 인덱스로 가려면..
//        if (isTotalExplore) {
//            return mainImageList.count - 1;
//        }
//        else {
//            // 작업하지 않은 마지막 이미지로 가려면..
//            for i in (0 ..< mainImageList.count).reversed() {
//                if let done = mainImageList.images[i].isLabelingDone {
//                    // 아직 라벨링 작업을 하지 않았으면 리턴
//                    p("인덱스 값 : ", i, ", ", done);
//                    if (!done) {
//                        return i;
//                    }
//                }
//                else {
//                    return i;
//                }
//            }
//            return currIndex;
//        }
//    }
//
    // -----------------------------------------------------------------------------------------
    // 참조 이미지 정보 다운로드
    // -----------------------------------------------------------------------------------------
    //var referImageList:[String] = []
    var referImageList:ReferImageList = ReferImageList()
    var referImages:[UIImage] = []
    
    func showReferImageScreen() {

        let alertProgressNoAction = UIAlertController(title: "참조 이미지 다운로드 중...\n\n\n", message: nil, preferredStyle: .alert)
        let spinnerIndicator = UIActivityIndicatorView(style: .whiteLarge)
        spinnerIndicator.center = CGPoint(x: 135.0, y: 85.5)
        spinnerIndicator.color = UIColor.black
        spinnerIndicator.startAnimating()
        alertProgressNoAction.view.addSubview(spinnerIndicator)
        self.present(alertProgressNoAction, animated: false, completion: nil)
        
        let success = getReferImageList()
        if (success) {
            loadReferImagesFromURL()
            alertProgressNoAction.dismiss(animated: false, completion: nil)
        }
        else {
            spinnerIndicator.removeFromSuperview()
            let otherAction = UIAlertAction(title: "OK", style: .default, handler: { action in
                alertProgressNoAction.dismiss(animated: true, completion: nil)
            })
            alertProgressNoAction.title = "메세지 확인\n\n\(LastURLErrorMessage)\n\n"
            alertProgressNoAction.addAction(otherAction)
            return
        }
        
        performSegue(withIdentifier: "segueReferImages", sender: nil)

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // -------------------------------------------------------------------------------
    // 네비게이션 BAR 블링크(blink) 처리
    // -------------------------------------------------------------------------------
    fileprivate var naviBarBlinkEndless = false
    fileprivate var naviBarBlinkRunning = false
    fileprivate var naviBarColor = UIColor.white

    func naviBarBlinkRunLoop() {
        
        self.naviBarBlinkRunning = true
        
        while (naviBarBlinkEndless) {

            if naviBarColor != UIColor.white {
                naviBarColor = UIColor.white
            }
            else {
                if (IsReviewMode) {
                    naviBarColor = UIColor.yellow
                }
//                else if (IncludeLabelingDoneImage) {
//                    naviBarColor = UIColor.green
//                }
                else {
                    naviBarColor = UIColor.white
                }
            }

            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.25) {
                    self.navigationController?.navigationBar.barTintColor = self.naviBarColor
                    self.navigationController?.navigationBar.layoutIfNeeded()
                }
            }
            
            Thread.sleep(forTimeInterval: 0.5)
        }
    }
    
    func naviBarBlinkStart() {
        
        if (naviBarBlinkRunning) {
            p("이미 title blink 프로세스가 동작중입니다.")
            return
        }
        
        DispatchQueue.global(qos: .background).async {
            p("title Blink Start")
            self.naviBarBlinkEndless = true
            self.naviBarBlinkRunLoop()
            DispatchQueue.main.async {
                p("title blink Stop")
                self.naviBarBlinkRunning = false
            }
        }
    }
    
    func naviBarBlinkStop() {
        if (!naviBarBlinkRunning) {
            p("이미 title blink 프로세스가 정지 상태입니다.")
            return
        }
        naviBarBlinkEndless = false
    }
    // -------------------------------------------------------------------------------


}

class DrawLineOnWidthSliderView: UIView {
    
    var lineColor:UIColor = UIColor.blue
    var lineWidth:CGFloat = 2.0

    override func draw(_ rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()
        context?.setLineWidth(lineWidth)
        context?.setStrokeColor(lineColor.cgColor)
        context?.setLineCap(.butt)
        context?.move(to: CGPoint(x:7, y: 35 + lineWidth / 2))
        context?.addLine(to: CGPoint(x: 82, y: 35 + lineWidth / 2))
        context?.strokePath()
    }
}
