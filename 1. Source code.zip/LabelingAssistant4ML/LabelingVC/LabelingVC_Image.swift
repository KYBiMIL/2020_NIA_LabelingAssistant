//
//  MainVC_Image.swift
//  LabelingAssistant4ML
//
//  Created by Myeong-Joon Son on 06/11/2018.
//  Copyright © 2018 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    //-------------------------------------------------------------------------------------
    // ScrollImage : 이미지의 확대/축소/확대된 이미지 이동 등을 위하여 사용, 이미지를 scroll view 안에서 사용
    //-------------------------------------------------------------------------------------
    func setScrollViewPropertyForImage() {
        //ScrollImage.delegate = self
        //scrollImage.backgroundColor = UIColor.darkGray
        ScrollImage.contentSize = EditingImage.bounds.size
        ScrollImage.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
        
        ScrollImage.alwaysBounceVertical = false
        ScrollImage.alwaysBounceHorizontal = false
        ScrollImage.showsVerticalScrollIndicator = true
        ScrollImage.flashScrollIndicators()
        
        // 최소 터치수를 최소2개, 최대2개로 설정
        // 싱글터치는 이미지 자체 Pan 이벤트로 사용함.(mark용도로)
        ScrollImage.panGestureRecognizer.minimumNumberOfTouches = 2
        ScrollImage.panGestureRecognizer.maximumNumberOfTouches = 2
        setImageZoomScaleInScrollView()
    }
    
    func setImageZoomScaleInScrollView() {
        let imageViewSize = EditingImage.bounds.size
        let scrollViewSize = ScrollImage.bounds.size
        let widthScale = scrollViewSize.width / imageViewSize.width
        let heightScale = scrollViewSize.height / imageViewSize.height
        
        ScrollImage.minimumZoomScale = min(widthScale, heightScale)
        ScrollImage.maximumZoomScale = ScrollImage.minimumZoomScale * 5.0
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return EditingImage
    }
    
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        widthSliderViewSetNeedsDisplay()
    }

    func downloadSourceImage(_ imageId:String, _ file_name:String) -> String? {
        
        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
        if let data = try? Data(contentsOf: url!) {
            
            //let source: CGImageSource = CGImageSourceCreateWithData(data as! CFMutableData, nil)!
            //let metadata = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [AnyHashable: Any]
            
            //p(metadata!)
            //p("DPIWidth  : ", metadata!["DPIWidth"] as! Int)
            //p("DPIHeight : ", metadata!["DPIHeight"] as! Int)
            
            let f = imageId + ".jpg"
            
            if (!makeDir(fullPath: sourceImageDirectoryURL!.path)) {
                p("downloadSourceImage() makeDir sourceImageDirectoryURL error")
            }
            
            let saveImageUrl = sourceImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
                //p("downloaded image save ok : ", saveImageUrl.path)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadSourceImage url : \(file_name)")
            return nil
        }
        
    }

    func downloadMarkedImage(_ imageId:String, _ file_name_url:URL) -> String? {

        let encoded = file_name_url.relativePath.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
        //p(url?.absoluteString)
        if let data = try? Data(contentsOf: url!) {
            
            //let source: CGImageSource = CGImageSourceCreateWithData(data as! CFMutableData, nil)!
            //let metadata = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [AnyHashable: Any]
            
            //p(metadata!)
            //p("DPIWidth  : ", metadata!["DPIWidth"] as! Int)
            //p("DPIHeight : ", metadata!["DPIHeight"] as! Int)
            
            //let f = markedImageNamePrefix + imageId + ".jpg"
            //let f = String(format: "%@%@.jpg", imageId, markedImageNameSuffix)
            let f = file_name_url.lastPathComponent
            if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
                p("downloadMarkedImage() makeDir markedImageDirectoryURL error")
            }
            
            let saveImageUrl = markedImageDirectoryURL!.appendingPathComponent(f)
            do {
                try data.write(to: saveImageUrl)
                //p("downloaded image save ok : ", saveImageUrl.path)
            } catch {
                p(error.localizedDescription)
            }
            
            return saveImageUrl.path
            
        }
        else {
            p("Error downloadMarkedImage url : \(file_name_url.relativePath)")
            return nil
        }
        
    }
    
    func uploadMarkedIndivisualImage(fileURL:URL, imageId:String, serverSourceImagePath:String, serverFileName:String, imageSeq:Int, line:Line?) {
        
        let serverMarkedImageDir = getMarkedImageDirectoryOnServer(serverSourceImagePath: serverSourceImagePath, imageId: imageId)
        //        첫번째 pathcomponent인 image를 제외할 경우에 사용
        //        var dirExceptImageRoot:URL = URL(fileURLWithPath: "")
        //        for (index, element) in serverMarkedImageDir.pathComponents.enumerated() {
        //            if (index > 1) {
        //                dirExceptImageRoot.appendPathComponent(element)
        //                p(dirExceptImageRoot.path)
        //            }
        //        }
        
        var imageInfoToUpload = ImageInfoToUpload()
        imageInfoToUpload.projectCode = WorkingProjectCode
        imageInfoToUpload.projectName = WorkingProjectName
        imageInfoToUpload.imageID = (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id : imageId
        imageInfoToUpload.imageSeq = imageSeq
        imageInfoToUpload.name = serverFileName
        imageInfoToUpload.location = serverMarkedImageDir.relativePath // 상대경로 지정, path로 하면 맨앞에 '/'이 붙어 서버에서 루트로 인식
        imageInfoToUpload.imageFileURL = fileURL
        ImagesToUpload.append(imageInfoToUpload)
        
        //uploadImageFile(to: markedImageNamePrefix + imageId, at: fileURL)
        
        //        p("markedLocation.path: ", markedLocation.path)
        //
        
    }
    // ----------------------------------------------------------------------
    // 마킹완료된 이미지 저장하기
    // ----------------------------------------------------------------------
    func saveMarkedImage(imageView:UIImageView, imageId:String) {
        
        // -----------------------------------------------------------------------------------
        // 여기는 전체 이미지 그대로 저장
        // -----------------------------------------------------------------------------------
        var serverFileName = String(format: "%@%@%03d", (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageId, markedImageNameSuffix, 0)
        var saveFileName = String(format: "%@.jpg", serverFileName)

        let imageFrame = imageView.frameOfImage
        
        var newImage:UIImage?
        
        if let layerShot = canvas.screenShot(size: ScrollImage.frame.size) {
            let croppedImage = layerShot.crop(rect: imageFrame)
            let resizedImage = croppedImage.resize(scale: imageView.imageScale)
            // 소스 이미지에 canvas 이미지를 오버레이
            newImage = imageView.image?.overlayWith(image: resizedImage!, posX: 0, posY: 0)
        }

        // 마킹이 되었을 경우에는 이미지를 저장해 놓음
        if (WorkingProjectMulti == "Y") {
            subImageArray[selectedSubImageRowNum].newMarking = true
            subImageArray[selectedSubImageRowNum].newMarkedImage = newImage
            subImageArray[selectedSubImageRowNum].mark_num = canvas.lines.count
            collectionViewThumbnail.reloadData()
        }
        else {
            imageArray[currentImageIndex].newMarking = true
            imageArray[currentImageIndex].newMarkedImage = newImage
            imageArray[currentImageIndex].markNum = canvas.lines.count
            collectionViewMainImage.reloadData()
        }
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
            p("saveMarkedImage() : makeDir markedImageDirectoryURL error")
        }
        
        // 저장할 파일명 URL 정의
        let saveImageURL = markedImageDirectoryURL!.appendingPathComponent(saveFileName)
        
        if (!saveImage(image: newImage!, writeTo: saveImageURL)) {
            p("saveMarkedImage() : saveImage is false.")
        }

        let serverSourceImagePath = imageArray[currentImageIndex].serverLocation!
        p("serverSourceImagePath: \(serverSourceImagePath)")

        // 저장된 파일 URL을 서버 위치에 업로드
        uploadMarkedIndivisualImage(fileURL: saveImageURL, imageId: imageId, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: 0, line: nil)

        serverFileName = String(format: "%@%@%03d", (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageId, markedImageNameSuffix, 1)
        saveFileName = String(format: "%@.jpg", serverFileName)
        let savedAllMarkUrl =  saveAllMarkWithoutImage(imageView: imageView, saveFileName: saveFileName, lines: canvas.lines)
        // 저장된 파일 URL을 서버 위치에 업로드
        uploadMarkedIndivisualImage(fileURL: savedAllMarkUrl, imageId: imageId, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: 1, line: nil)

        // -----------------------------------------------------------------------------------
        // 여기서부터는 마크 하나하나 개별적으로 저장
        // -----------------------------------------------------------------------------------
        var count = 1
        canvas.lines.forEach { (line) in
            
            count = count + 1
            var markLine = line
            
            markLine.alpha = 1.0
            markLine.fillcolor = markLine.color
            markLine.isClip = false                     // 저장할 경우에는 클립핑영역도 제대로 저장

            // 저장할 이미지 명 만들기
            let serverFileName = String(format: "%@%@%03d",(WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageId, markedImageNameSuffix, count)
            let saveFileName = String(format: "%@.jpg", serverFileName)

            // 이미지 저장후 저장된 파일 URL을 리턴받음
            let savedImageUrl = saveIndivisualCanvas(imageView: imageView, saveFileName: saveFileName, line: markLine)
            
            // 저장된 파일 URL을 서버 위치에 업로드
            uploadMarkedIndivisualImage(fileURL: savedImageUrl, imageId: imageId, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: count, line: markLine)

        }

    }
    
    func saveIndivisualCanvas(imageView:UIImageView, saveFileName:String, line:Line) -> URL {
        
        let indiCanvas = Canvas()
        indiCanvas.frame = canvas.frame
        indiCanvas.isClosedCurve = true
        indiCanvas.lineWidth = lineWidth
        // -----------------------
        
        indiCanvas.backgroundColor = UIColor.black
        
        indiCanvas.lines.append(line)
        
        let imageFrame = imageView.frameOfImage
        print("imageFrame : ", imageFrame)
        
        var resizedImage:UIImage?
        var newImage:UIImage?

        // 원본 이미지의 실제 사이즈 구하기
        let originalImageSize = CGSize(width: imageView.image!.size.width * imageView.image!.scale, height: imageView.image!.size.height * imageView.image!.scale)
        
        if let layerShot = indiCanvas.screenShot(size: ScrollImage.frame.size) {
            let croppedImage = layerShot.crop(rect: imageFrame)
            resizedImage = croppedImage.resize(scale: imageView.imageScale)
            // 빈 이미지에 canvas 이미지를 오버레이
            newImage = getEmptyImage(size: originalImageSize).overlayWith(image: resizedImage!, posX: 0, posY: 0)
        }
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
            p("saveMarkedImage() : makeDir markedImageDirectoryURL error")
        }
        
        // 저장할 파일명 URL 정의
        let saveImageURL = markedImageDirectoryURL!.appendingPathComponent(saveFileName)
        
        if (!saveImage(image: newImage!, writeTo: saveImageURL)) {
            print("saveMarkedImage() saveImage is false.")
        }
        
        return saveImageURL

    }
    
    // --------------------------------------------------------------------------------------
    // 정해진 크기의 이미지를 색상 없이 생성
    // --------------------------------------------------------------------------------------
    func getEmptyImage(size: CGSize) -> UIImage {
        let rect = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        UIColor.clear.setFill()
        UIRectFill(rect)
        let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return image
    }

    func saveAllMarkWithoutImage(imageView:UIImageView, saveFileName:String, lines:[Line]) -> URL {
        
        let indiCanvas = Canvas()
        indiCanvas.frame = canvas.frame
        indiCanvas.isClosedCurve = true
        indiCanvas.lineWidth = lineWidth
        // -----------------------
        
        indiCanvas.backgroundColor = UIColor.black
        
        canvas.lines.forEach { (line) in
            var l = line
            l.alpha = 1.0
            l.fillcolor = l.color
            indiCanvas.lines.append(l)
        }
        

        let imageFrame = imageView.frameOfImage
        print("imageFrame : ", imageFrame)
        
        var resizedImage:UIImage?
        var newImage:UIImage?

        // 원본 이미지의 실제 사이즈 구하기
        let originalImageSize = CGSize(width: imageView.image!.size.width * imageView.image!.scale, height: imageView.image!.size.height * imageView.image!.scale)

        if let layerShot = indiCanvas.screenShot(size: ScrollImage.frame.size) {
            let croppedImage = layerShot.crop(rect: imageFrame)
            resizedImage = croppedImage.resize(scale: imageView.imageScale)
            // 빈 이미지에 canvas 이미지를 오버레이
            newImage = getEmptyImage(size: originalImageSize).overlayWith(image: resizedImage!, posX: 0, posY: 0)
        }
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
            p("saveMarkedImage() : makeDir markedImageDirectoryURL error")
        }
        
        // 저장할 파일명 URL 정의
        let saveImageURL = markedImageDirectoryURL!.appendingPathComponent(saveFileName)
        
        if (!saveImage(image: newImage!, writeTo: saveImageURL)) {
            print("saveMarkedImage() saveImage is false.")
        }
        
        return saveImageURL
        
    }
    
    

//    // ----------------------------------------------------------------------
//    // 저장된 마킹 완료된 이미지 불러오기
//    // ----------------------------------------------------------------------
//    func loadMarkedImage(imageView:UIImageView, imageId:String) {
//        
//        let f = markedImageNamePrefix + imageId + ".jpg"
//        
//        // 마킹된 이미지 저장 디렉토리에 있는 파일들 나열
//        getFileListInDocument(subpath: markedImageDirectoryName)
//        
//        if let savedImage = getSavedImage(filename: f, subpath: markedImageDirectoryName) {
//            imageView.image = savedImage
//        }
//        else {
//            p("loadMarkedImage() getSavedImage call error!")
//            return
//        }
//        
//        imageView.clipsToBounds = true
//        imageView.contentMode = .scaleAspectFit
//    }
    

}

//extension LabelingVC {
//
//    //-------------------------------------------------------------------------------------
//    // ScrollImage : 이미지의 확대/축소/확대된 이미지 이동 등을 위하여 사용, 이미지를 scroll view 안에서 사용
//    //-------------------------------------------------------------------------------------
//    func setScrollViewPropertyForImage() {
//        //ScrollImage.delegate = self
//        ScrollImage.backgroundColor = UIColor.darkGray
//        ScrollImage.contentSize = EditingImage.bounds.size
//        ScrollImage.autoresizingMask = [UIView.AutoresizingMask.flexibleWidth, UIView.AutoresizingMask.flexibleHeight]
//        
//        ScrollImage.alwaysBounceVertical = false
//        ScrollImage.alwaysBounceHorizontal = false
//        ScrollImage.showsVerticalScrollIndicator = true
//        ScrollImage.flashScrollIndicators()
//        
//        // 최소 터치수를 최소2개, 최대2개로 설정
//        // 싱글터치는 이미지 자체 Pan 이벤트로 사용함.(mark용도로)
//        ScrollImage.panGestureRecognizer.minimumNumberOfTouches = 2
//        ScrollImage.panGestureRecognizer.maximumNumberOfTouches = 2
//        setImageZoomScaleInScrollView()
//    }
//    
//    func setImageZoomScaleInScrollView() {
//        let imageViewSize = EditingImage.bounds.size
//        let scrollViewSize = ScrollImage.bounds.size
//        let widthScale = scrollViewSize.width / imageViewSize.width
//        let heightScale = scrollViewSize.height / imageViewSize.height
//        
//        ScrollImage.minimumZoomScale = min(widthScale, heightScale)
//        ScrollImage.maximumZoomScale = ScrollImage.minimumZoomScale * 6.0
//    }
//    
//    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
//        return EditingImage
//    }
//    
//    func initImageZoomScale() {
//        ScrollImage.zoomScale = 1
//    }
//
//    func addControlPointForEllipse(layer:CAShapeLayer) {
//        
//        let origin = CGPoint(x:0,y:0)
//        let size = layer.frame.size
//        
//        let color = UIColor.yellow.cgColor
//        
//        // outline 추가
//        let shapeLayer:CAShapeLayer = CAShapeLayer()
//        let shapeRect = CGRect(x: 0, y: 0, width: size.width, height: size.height)
//        
//        shapeLayer.fillColor = UIColor.clear.cgColor
//        shapeLayer.strokeColor = color
//        shapeLayer.lineWidth = 1
//        shapeLayer.lineDashPattern = [1,1]
//        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 0).cgPath
//        shapeLayer.frame = CGRect(x:origin.x, y:origin.y, width:size.width, height:size.height)
//        outlineLayer = shapeLayer
//        layer.addSublayer(shapeLayer)
//        
//        // 꼭지점마다 컨트롤포인트 추가
//        let controlPointSize = CGSize(width: 60, height: 60)
//        let controlPointLayer:CAShapeLayer = CAShapeLayer()
//        controlPointLayer.fillColor = UIColor.clear.cgColor
//        controlPointLayer.strokeColor = color
//        controlPointLayer.lineWidth = 1
//        //controlPointLayer.lineDashPattern = [1,1]
//        controlPointLayer.path =
//            UIBezierPath(ovalIn:CGRect(x: 0, y: 0, width: controlPointSize.width, height: controlPointSize.height)).cgPath
//        controlPointLayer.frame = CGRect(origin: CGPoint(x:0,y:0), size: controlPointSize)
//        
//        let controlPointLayerTopLeft = controlPointLayer.copyLayer()
//        let controlPointLayerTopRight = controlPointLayer.copyLayer()
//        let controlPointLayerBottomLeft = controlPointLayer.copyLayer()
//        let controlPointLayerBottomRight = controlPointLayer.copyLayer()
//        
//        controlPointLayerTopLeft.frame =
//            CGRect(origin: CGPoint(x:origin.x - controlPointSize.width/2,
//                                   y:origin.y - controlPointSize.height/2),
//                   size: controlPointSize)
//        controlPointLayerTopRight.frame =
//            CGRect(origin: CGPoint(x: origin.x + size.width - controlPointSize.width/2,
//                                   y: origin.y - controlPointSize.height/2),
//                   size: controlPointSize)
//        controlPointLayerBottomLeft.frame =
//            CGRect(origin: CGPoint(x:origin.x - controlPointSize.width/2,
//                                   y: origin.y + size.height - controlPointSize.height/2),
//                   size: controlPointSize)
//        controlPointLayerBottomRight.frame =
//            CGRect(origin: CGPoint(x:origin.x + size.width - controlPointSize.width/2,
//                                   y: origin.y + size.height - controlPointSize.height/2),
//                   size: controlPointSize)
//        
//        layer.addSublayer(controlPointLayerTopLeft)
//        layer.addSublayer(controlPointLayerTopRight)
//        layer.addSublayer(controlPointLayerBottomLeft)
//        layer.addSublayer(controlPointLayerBottomRight)
//        
//        controlPoints.append(controlPointLayerTopLeft)
//        controlPoints.append(controlPointLayerTopRight)
//        controlPoints.append(controlPointLayerBottomLeft)
//        controlPoints.append(controlPointLayerBottomRight)
//        
//        for (index, element) in controlPoints.enumerated() {
//            p("enumerated:", index, ":", element.frame)
//        }
//        
//    }
//    
//    //--------------------------------------------------------------------------------
//    // 이미지 위의 타원, 다각형을 이동 및 크기 조정 등
//    //--------------------------------------------------------------------------------
//    func adjustMark(gesture: UIPanGestureRecognizer) {
//        
//        let currentPoint = gesture.location(in: EditingImage)
//        switch gesture.state {
//        case .began:
//            panPrevPoint = currentPoint
//            isExistSelectedMark = false
//            isExistSelectedControlPoint = false
//            
//            // 마크 편집 모드이면 먼저 편집중인 마크가 선택되었는지 체크한 후
//            // control point가 선택되었는지 먼저 체크
//            if (isEditMode) {
//                if (editModeMarkShape.layer!.frame.contains(currentPoint)) {
//                    isExistSelectedMark = true
//                    selectedMark = editModeMarkShape
//                }
//                else {
//                    let editMarkPoint = CGPoint(x:currentPoint.x - editModeMarkShape.layer!.frame.origin.x,
//                                                y:currentPoint.y - editModeMarkShape.layer!.frame.origin.y)
//                    for (index, controlPoint) in controlPoints.enumerated() {
//                        if controlPoint.frame.contains(editMarkPoint) {
//                            selectedControlPoint = controlPoint
//                            isExistSelectedControlPoint = true
//                            selectedControlPointPosition = index
//                            selectedMark = editModeMarkShape
//                        }
//                    }
//                }
//            }
//            
//            // 편집모드 상황에서 선택된 control point가 없을 경우에 다른 mark 선택 여부를 체크함
//            if (!isExistSelectedMark && !isExistSelectedControlPoint) {
//                for item in arrayMarkShapeLayer {
//                    if let layer = item.layer {
//                        if layer.frame.contains(currentPoint) {
//                            selectedMark = item
//                            //selectedShapeLayer = layer
//                            isExistSelectedMark = true
//                            // edit mode에서 다른 layer가 선택되었으면 변경
//                            if (isEditMode && selectedMark.layer != editModeMarkShape.layer) {
//                                enterEditMode(markShape: selectedMark)
//                            }
//                        }
//                    }
//                }
//            }
//            
//            if (isExistSelectedMark || isExistSelectedControlPoint) {
//                markAdjustBegan(markShape: selectedMark)
//            }
//            break
//            
//        case .ended, .cancelled, .failed:
//            if (isExistSelectedMark || isExistSelectedControlPoint) {
//                markAdjustEnded(markShape: selectedMark)
//            }
//            break
//            
//        case .changed:
//            
//            touchPosition.text = String(format: "(%5.1f,%5.1f)", currentPoint.x, currentPoint.y)
//            
//            if (isExistSelectedControlPoint) {
//                // control point의 이동으로 인한 사이즈 조정
//                moveControlPoint(markShape: editModeMarkShape, controlPoint: selectedControlPoint,
//                                 position: selectedControlPointPosition,
//                                 x: currentPoint.x, y: currentPoint.y)
//            }
//            else if (isExistSelectedMark) {
//                // 선택된 마크가 있을 경우에 이동
//                if (isEditMode && selectedMark.layer == editModeMarkShape.layer) {
//                    moveEllipse(markShape: selectedMark, x: currentPoint.x, y: currentPoint.y)
//                }
//                else {
//                    moveEllipse(markShape: selectedMark, x: currentPoint.x, y: currentPoint.y)
//                }
//            }
//            
//            break
//            
//        default:
//            p("imagePanned etc. : ", gesture.state.rawValue)
//            break
//        }
//        
//    }
//    
//
//    func drawEllipse(rect:CGRect) {
//        
//        // 타원 최초 크기 설정
//        let width = rect.width
//        let height = rect.height
//        let pointx = rect.origin.x
//        let pointy = rect.origin.y
//        
//        // 타원 정의
//        let rect = CGRect(x: 0, y: 0, width: width, height: height)
//        let ovalPath = UIBezierPath(ovalIn: rect)
//        
//        // shapeLayer 생성
//        let shapeLayer = CAShapeLayer()
//        shapeLayer.path = ovalPath.cgPath               // 정의된 타원을 layer에 지정
//        shapeLayer.fillColor = UIColor.clear.cgColor
//        shapeLayer.strokeColor = UIColor.red.cgColor
//        shapeLayer.lineWidth = 2.0
//        shapeLayer.frame = CGRect(x:pointx, y:pointy, width:width, height:height)
//        
//        addMarkEllipse(shapeLayer: shapeLayer, rect: shapeLayer.frame)
//        
//        writeLabelMarkInfo(shapeLayer: shapeLayer)
//        
//    }
//    
//    // 화면상에서 터치한 포인트를 기준으로 디폴트 타원을 그린다.
//    func drawEllipse(x: CGFloat, y: CGFloat) {
//        
//        // 타원 최초 크기 설정
//        let width = CGFloat(160)
//        let height = CGFloat(160)
//        let pointx = x - width / 2
//        let pointy = y - height / 2
//        
//        drawEllipse(rect: CGRect(x: pointx, y: pointy, width: width, height: height))
//        
////        // 타원 정의
////        let rect = CGRect(x: 0, y: 0, width: width, height: height)
////        let ovalPath = UIBezierPath(ovalIn: rect)
////
////        // shapeLayer 생성
////        let shapeLayer = CAShapeLayer()
////        shapeLayer.path = ovalPath.cgPath               // 정의된 타원을 layer에 지정
////        shapeLayer.fillColor = UIColor.clear.cgColor
////        shapeLayer.strokeColor = UIColor.red.cgColor
////        shapeLayer.lineWidth = 2.0
////        shapeLayer.frame = CGRect(x:pointx, y:pointy, width:width, height:height)
////
////        addMarkEllipse(shapeLayer: shapeLayer, rect: shapeLayer.frame)
////
////        writeLabelMarkInfo(shapeLayer: shapeLayer)
//        
//    }
//    
//    func writeLabelMarkInfo(shapeLayer: CAShapeLayer) {
//        if let ratio = imageRealViewRatio {
//            let realFrame = shapeLayer.frame.transToRealShape(EditingImage.imageOrigin(), ratio)
//            selectedMarkInfo.text = String(format: "(x:%5.1f, y:%5.1f, w:%5.1f, h:%5.1f)",
//                                           realFrame.origin.x, realFrame.origin.y,
//                                           realFrame.width, realFrame.height)
//        }
//    }
//    
//    // ------------------------------------------------------------------------------
//    // 마크 이동, 컨트롤포인트 조절
//    // ------------------------------------------------------------------------------
//    func moveEllipse(markShape: MarkShape, x: CGFloat, y: CGFloat) {
//        
//        let shapeLayer = markShape.layer!
//        
//        let prevOrigin = shapeLayer.frame.origin
//        let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
//        
//        panPrevPoint = CGPoint(x:x, y:y)
//        
//        let newOrigin = CGPoint(x:prevOrigin.x + gapPoint.x, y:prevOrigin.y + gapPoint.y)
//        disableAnimation {
//            shapeLayer.frame.origin = newOrigin
//        }
//        markShape.shape = shapeLayer.frame
//        
//        writeLabelMarkInfo(shapeLayer: shapeLayer)
//        
//    }
//    
//    func moveControlPoint(markShape: MarkShape, controlPoint: CAShapeLayer, position:Int, x: CGFloat, y: CGFloat) {
//        
//        let shapeLayer = markShape.layer!
//        
//        // 이동 정지 여부 체크
//        var pointx = x
//        var pointy = y
//        let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
//        
//        switch position {
//        case 0: // TopLeft
//            if (shapeLayer.frame.origin.x + gapPoint.x >= shapeLayer.frame.origin.x + shapeLayer.frame.width) {
//                pointx = panPrevPoint.x
//            }
//            if (shapeLayer.frame.origin.y + gapPoint.y >= shapeLayer.frame.origin.y + shapeLayer.frame.height) {
//                pointy = panPrevPoint.y
//            }
//            break
//        case 1: // TopRight
//            if (shapeLayer.frame.origin.x + shapeLayer.frame.width + gapPoint.x <= shapeLayer.frame.origin.x) {
//                pointx = panPrevPoint.x
//            }
//            if (shapeLayer.frame.origin.y + gapPoint.y >= shapeLayer.frame.origin.y + shapeLayer.frame.height) {
//                pointy = panPrevPoint.y
//            }
//            break
//        case 2: // BottomLeft
//            if (shapeLayer.frame.origin.x + gapPoint.x >= shapeLayer.frame.origin.x + shapeLayer.frame.width) {
//                pointx = panPrevPoint.x
//            }
//            if (shapeLayer.frame.origin.y + shapeLayer.frame.height + gapPoint.y <= shapeLayer.frame.origin.y) {
//                pointy = panPrevPoint.y
//            }
//            break
//        case 3: // BottomRight
//            if (shapeLayer.frame.origin.x + shapeLayer.frame.width + gapPoint.x <= shapeLayer.frame.origin.x) {
//                pointx = panPrevPoint.x
//            }
//            if (shapeLayer.frame.origin.y + shapeLayer.frame.height + gapPoint.y <= shapeLayer.frame.origin.y) {
//                pointy = panPrevPoint.y
//            }
//            break
//        default:
//            break
//        }
//        
//        // control point 이동
//        moveControlPoints(markShape:markShape, controlPoint: controlPoint, position: position, x: pointx, y: pointy)
//        
//    }
//    
//    func moveControlPoints(markShape:MarkShape, controlPoint: CAShapeLayer, position:Int, x: CGFloat, y: CGFloat) {
//        
//        let shapeLayer = markShape.layer!
//        
//        let gapPoint = CGPoint(x:x - panPrevPoint.x, y:y - panPrevPoint.y)
//        var newOrigin:CGPoint = CGPoint()
//        var index = 0
//        
//        switch position {
//        case 0:
//            // mark layer, topleft control layer
//            newOrigin = CGPoint(x:shapeLayer.frame.origin.x + gapPoint.x,
//                                y:shapeLayer.frame.origin.y + gapPoint.y)
//            disableAnimation {
//                shapeLayer.frame.origin = newOrigin
//            }
//            
//            // topright control layer
//            index = 1
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x - gapPoint.x,
//                                y:controlPoints[index].frame.origin.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            
//            // bottomleft control layer
//            index = 2
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x,
//                                y:controlPoints[index].frame.origin.y - gapPoint.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            
//            // bottomright control layer
//            index = 3
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x - gapPoint.x,
//                                y:controlPoints[index].frame.origin.y - gapPoint.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            break
//        case 1:
//            // mark layer, topleft control layer
//            newOrigin = CGPoint(x:shapeLayer.frame.origin.x,
//                                y:shapeLayer.frame.origin.y + gapPoint.y)
//            disableAnimation {
//                shapeLayer.frame.origin = newOrigin
//            }
//            
//            // topright control layer
//            index = 1
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x + gapPoint.x,
//                                y:controlPoints[index].frame.origin.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            
//            // bottomleft control layer
//            index = 2
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x,
//                                y:controlPoints[index].frame.origin.y - gapPoint.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            // bottomright control layer
//            index = 3
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x + gapPoint.x,
//                                y:controlPoints[index].frame.origin.y - gapPoint.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            break
//        case 2:
//            // mark layer, topleft control layer
//            newOrigin = CGPoint(x:shapeLayer.frame.origin.x + gapPoint.x,
//                                y:shapeLayer.frame.origin.y)
//            disableAnimation {
//                shapeLayer.frame.origin = newOrigin
//            }
//            
//            // topright control layer
//            index = 1
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x - gapPoint.x,
//                                y:controlPoints[index].frame.origin.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            
//            // bottomleft control layer
//            index = 2
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x,
//                                y:controlPoints[index].frame.origin.y + gapPoint.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            
//            // bottomright control layer
//            index = 3
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x - gapPoint.x,
//                                y:controlPoints[index].frame.origin.y + gapPoint.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            break
//        case 3:
//            // topright control layer
//            index = 1
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x + gapPoint.x,
//                                y:controlPoints[index].frame.origin.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            
//            // bottomleft control layer
//            index = 2
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x,
//                                y:controlPoints[index].frame.origin.y + gapPoint.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            
//            // bottomright control layer
//            index = 3
//            newOrigin = CGPoint(x:controlPoints[index].frame.origin.x + gapPoint.x,
//                                y:controlPoints[index].frame.origin.y + gapPoint.y)
//            disableAnimation {
//                controlPoints[index].frame.origin = newOrigin
//            }
//            break
//        default:
//            break
//        }
//        
//        // outline과 ellipse 사이즈 조정
//        let shapeWidth = controlPoints[1].frame.origin.x - controlPoints[0].frame.origin.x
//        let shapeHeight = controlPoints[2].frame.origin.y - controlPoints[0].frame.origin.y
//        let shapeSize = CGSize(width: shapeWidth, height: shapeHeight)
//        let shapeRect = CGRect(origin: .zero, size: shapeSize)
//        
//        disableAnimation {
//            shapeLayer.path = UIBezierPath(ovalIn:shapeRect).cgPath
//            shapeLayer.frame = CGRect(origin: shapeLayer.frame.origin, size: shapeSize)
//            outlineLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 0).cgPath
//            outlineLayer.frame = CGRect(origin: .zero, size: shapeSize)
//        }
//        
//        panPrevPoint = CGPoint(x:x, y:y)
//        
//        markShape.shape = shapeLayer.frame
//
//        writeLabelMarkInfo(shapeLayer: shapeLayer)
//
//    }
//    
//
//}
