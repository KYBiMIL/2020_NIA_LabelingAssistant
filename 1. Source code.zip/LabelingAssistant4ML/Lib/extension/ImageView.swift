//
//  ImageView.swift
//  testSaveImage
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension UIImageView {
    // ------------------------------------------------------------------
    // imageview안에 표시되어 있는 image frame 가져오기
    // ------------------------------------------------------------------
    var frameOfImage:CGRect {
        let image = self.image!
        let wi = image.size.width
        let hi = image.size.height
        p("wi:\(wi), hi:\(hi)")
        
        let wv = self.frame.width
        let hv = self.frame.height
        p("wv:\(wv), hv:\(hv)")
        
        let ri:Double = Double(hi) / Double(wi)
        let rv:Double = Double(hv) / Double(wv)
        p("ri:\(ri), rv:\(rv)")
        
        var x, y, w, h: Double
        
        if ri > rv {
            h = Double(hv)
            w = h / ri
            x = (Double(wv) / 2) - (w / 2)
            y = 0
        } else {
            w = Double(wv)
            h = w * ri
            x = 0
            y = (Double(hv) / 2) - (h / 2)
        }
        
        return CGRect(x: x, y: y, width: w, height: h)
    }
    
    // ------------------------------------------------------------------
    // uiimageview frame 대비 실제 image 크기의 비율 가져오기
    // ------------------------------------------------------------------
    var imageScale:CGFloat {
        // scrollimage의 폭 대비 높이 비율
        let rateOfImageViewHeightByWidth = self.frame.size.height / self.frame.size.width
        let rateOfRealImageHeightByWidth = self.image!.size.height / self.image!.size.width
        
        var scale:CGFloat
        
        if (rateOfImageViewHeightByWidth > rateOfRealImageHeightByWidth) {
            scale = (self.image?.size.width)! / self.frame.size.width
            p("extension UIImageView : originalImageByViewScale Height base : ", scale)
        }
        else {
            scale = (self.image?.size.height)! / self.frame.size.height
            p("extension UIImageView : originalImageByViewScale Width Base: ", scale)
        }
        return scale
    }
    
    // ------------------------------------------------------------------
    // 실제 이미지 크기 대비 uiimageview frame 비율 가져오기
    // ------------------------------------------------------------------
    var frameScale:CGFloat {
        // scrollimage의 폭 대비 높이 비율
        let rateOfImageViewHeightByWidth = self.frame.size.height / self.frame.size.width
        let rateOfRealImageHeightByWidth = self.image!.size.height / self.image!.size.width
        
        var scale:CGFloat
        
        if (rateOfImageViewHeightByWidth > rateOfRealImageHeightByWidth) {
            scale = self.frame.size.width / (self.image?.size.width)!
            p("extension UIImageView : frameScale Height base : ", scale)
        }
        else {
            scale = self.frame.size.height / (self.image?.size.height)!
            p("extension UIImageView : frameScale Width Base: ", scale)
        }
        return scale
    }
    
    func drawFrame(frame:CGRect, color:UIColor, width:CGFloat) -> UIView {
        let frameIdentifyBorderView = UIView(frame: frame)
        frameIdentifyBorderView.layer.borderWidth = width
        frameIdentifyBorderView.layer.borderColor = color.cgColor
        self.addSubview(frameIdentifyBorderView)
        return frameIdentifyBorderView
    }
    
}
