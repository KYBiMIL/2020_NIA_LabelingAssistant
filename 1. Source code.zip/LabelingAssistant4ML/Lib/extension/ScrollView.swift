//
//  ScrollView.swift
//  testSaveImage
//
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension UIScrollView {
    
//    override open func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        p("extension UIScrollView : touchesBegan")
//        self.next?.touchesBegan(touches, with: event)
//    }
//
//    override open func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
//        p("extension UIScrollView : touchesMoved")
//        self.next?.touchesMoved(touches, with: event)
//    }
//
//    override open func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
//        p("extension UIScrollView : touchesEnded")
//        self.next?.touchesEnded(touches, with: event)
//    }
//
//    override open func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
//        p("extension UIScrollView : touchesCancelled")
//        self.next?.touchesEnded(touches, with: event)
//    }
    
}

@objc protocol PassTouchesImageViewDelegate {
    @objc optional func imageTouchesBegan()
    @objc optional func imageTouchesMoved()
    @objc optional func imageTouchesEnded()
    @objc optional func imageTouchesCanceled()
}

class PassTouchesImageView: UIImageView {
    
    var delegatePass : PassTouchesImageViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
//    func touchesBegan(touches: Set<NSObject>, withEvent event: UIEvent) {
//        p("touchesBegan")
//        self.delegatePass?.imageTouchesBegan()
//    }
//    func touchesMoved(touches: Set<NSObject>, withEvent event: UIEvent) {
//        self.delegatePass?.imageTouchesMoved()
//    }
//    func touchesEnded(touches: Set<NSObject>, withEvent event: UIEvent) {
//        self.delegatePass?.imageTouchesEnded()
//    }
//    func touchesCancelled(touches: Set<NSObject>, withEvent event: UIEvent) {
//        self.delegatePass?.imageTouchesCanceled()
//    }
    
    override open func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        p("extension UIImageView : touchesBegan")
        self.next?.touchesBegan(touches, with: event)
        self.delegatePass?.imageTouchesBegan!()
    }
    
    override open func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        p("extension UIImageView : touchesMoved")
        self.next?.touchesMoved(touches, with: event)
        self.delegatePass?.imageTouchesMoved!()
    }
    
    override open func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        p("extension UIImageView : touchesEnded")
        self.next?.touchesEnded(touches, with: event)
        self.delegatePass?.imageTouchesEnded!()
    }
    
    override open func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        p("extension UIImageView : touchesCancelled")
        self.next?.touchesEnded(touches, with: event)
        self.delegatePass?.imageTouchesCanceled!()
    }
    

}


extension UIImageView {
    
    override open func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        p("extension UIImageView : touchesBegan")
        self.next?.touchesBegan(touches, with: event)
    }

    override open func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        p("extension UIImageView : touchesMoved")
        self.next?.touchesMoved(touches, with: event)
    }

    override open func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        p("extension UIImageView : touchesEnded")
        self.next?.touchesEnded(touches, with: event)
    }

    override open func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        p("extension UIImageView : touchesCancelled")
        self.next?.touchesEnded(touches, with: event)
    }
    
}

